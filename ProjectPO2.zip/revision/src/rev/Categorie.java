package rev;

public class Categorie {


private int id;
private String nomCat;


//Constructeurs
public Categorie(int id, String nomCat) {
	
	this.id = id;
	this.nomCat = nomCat;
}


public Categorie() {
	
}


//Getters et setters
public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


public String getNomCat() {
	return nomCat;
}


public void setNomCat(String nomCat) {
	this.nomCat = nomCat;
}


@Override
public String toString() {
	return "Categorie = "+ nomCat;
}

















}
