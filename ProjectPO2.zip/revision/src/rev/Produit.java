package rev;

public class Produit{

// Concept d'encapsulation
	private int id ;
	private String nom;
	private double prix;
	private String description;
	private double poids;
	private Categorie cat;
	
// Constructeurs
	
	
	
	
public Produit(int id, String nom, double prix, String description, double poids, Categorie cat) {
	this.id = id;
	this.nom = nom;
	this.prix = prix;
	this.description = description;
	this.poids = poids;
	this.cat = cat;
}
	

public Produit() {

	
}


//  Getters & Setters
	public int getId() {
		return id;
	}
	

	
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public double getPrix() {
		return prix;
	}
	public void setPrix(double prix) {
		this.prix = prix;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPoids() {
		return poids;
	}
	public void setPoids(double poids) {
		this.poids = poids;
	}
	
	
	
	
	public Categorie getCat() {
		return cat;
	}


	public void setCat(Categorie cat) {
		this.cat = cat;
	}


		//Affichage
		public String toString() {
			return "Produit [id=" + id + ", nom=" + nom + ", prix=" + prix + ", description=" + description + ", poids="
					+ poids +"  , "+ cat + "]";
		}


	
	
	
	
	
	
	


	


}
