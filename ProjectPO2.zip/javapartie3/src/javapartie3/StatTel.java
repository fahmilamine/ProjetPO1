/*package javapartie3;

public class StatTel {
	
	static void formaterTel(String tel, String nom) {
		
		System.out.println("T�l�phone de "+ nom+" :  ("+tel.substring(0, 3)+") "+tel.substring(3,6)+ " - " + tel.substring(6));
		
	}
	
	static void compterChiffre(String tel,char x, String nom) {
		int compteur = 0;
		
		for(int i=0; i<tel.length(); i++) {
			if(tel.charAt(i)==x)
				compteur++;
			
		}
		
		
		System.out.println("il y a  "+ compteur+ " le chiffre " + x +" dans le numero de telephone de "+nom); 
	}
	
	
	static void compterMod(String tel, String nom, char mode) {
		int compteurPair = 0, compteurImpair =0;
		 
		
		for(int i=0; i<tel.length(); i++) {
			if(Integer.parseInt(String.valueOf(tel.charAt(i)))%2 ==0)
				compteurPair++;
			else
				compteurImpair++;
		    }
		
		if(mode=='p')
		   System.out.println("il y a  "+ compteurPair+ " le chiffre " + x +" dans le numero de telephone de "+nom); 
		else if (mode == 'i')	
			System.out.println("il y a  "+ compteurImpair+ " le chiffre " + x +" dans le numero de telephone de "+nom); 
		else 
			System.out.println("Le mode est incorrect"); 
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String telAlex =  "5143436111",  telJean = "4501234567";
		
		formaterTel(telAlex, "Alex");
		formaterTel(telJean, "Jean");
		
		compterChiffre("5143436111",'3', "Alex");
		
	
	
	}

}
*/
