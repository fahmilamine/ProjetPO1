package javapartie3;

public class Diviseur {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 // declaration de 3 constantes
		/*	   final int NOMBRE1 =  6,
			             NOMBRE2 = 20,
			             NOMBRE3 = 17;
			   int rang;

			   // afficher les diviseurs de 6 :
			    rang = 0;
			    System.out.printf("Les diviseurs de %d sont : \n", NOMBRE1);
			    for(int candidat = 1 ; candidat <= NOMBRE1 ; candidat++)
			    	if (NOMBRE1 % candidat == 0) 	{
			    		rang++;
			    		System.out.printf("%3d) %8d\n", rang, candidat);
			    	}
			    System.out.printf("\n");

			    // afficher les diviseurs de 20 :
			    rang = 0;
			    System.out.printf("Les diviseurs de %d sont : \n", NOMBRE2);
			    for(int candidat = 1 ; candidat <= NOMBRE2 ; candidat++)
			    	if (NOMBRE2 % candidat == 0)
			    	{
			    		rang++;
			    		System.out.printf("%3d) %8d\n", rang, candidat);
			    	}
			    System.out.printf("\n");

			    // afficher les diviseurs de 17
			    rang = 0;
			    System.out.printf("Les diviseurs de %d sont : \n", NOMBRE3);
			    for(int candidat = 1 ; candidat <= NOMBRE3 ; candidat++)
			    	if (NOMBRE3 % candidat == 0)
			    	{
			    		rang++;
			    		System.out.printf("%3d) %8d\n", rang, candidat);
			    	}
			    System.out.printf("\n");
			    
			    */
			    
               int  rang =0;
               int somme =0;
				int nombre = 5;
				while(nombre <=1000) {
					
					  for(int candidat = 1 ; candidat < nombre ; candidat++) {
					    	if (nombre % candidat == 0)
					    	{
					    		somme +=candidat;
					    		
					    	}
					  }
					
					  if (nombre == somme) {
						  System.out.println("Nombre parfait :" + nombre);
						  
					  }
					somme =0;
					nombre ++;
				}
			}
			

	
	
	

}
