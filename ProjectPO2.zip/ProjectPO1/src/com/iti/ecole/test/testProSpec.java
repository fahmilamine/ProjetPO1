package com.iti.ecole.test;

import java.util.ArrayList;

import com.iti.ecole.Professeur;
import com.iti.ecole.Specialite;

public class testProSpec {

	public static void main(String[] args) {
		
		
		Specialite spec1 = new Specialite("RO420-1589", "JAVA/JEE");
		Specialite spec2 = new Specialite("RO420-1590", ".Net");
		Specialite spec3 = new Specialite("RO420-1591", "Gestion de projet");
		Specialite spec4 = new Specialite("RO420-1592", "CISCO");
		Specialite spec5 = new Specialite("RO420-1593", "PHP");
		
		
		Professeur prof1 = new Professeur("Alexa", "Alexandre", "438-987-6969", "ALE@gmail.com", spec1);
		Professeur prof2 = new Professeur("Roso", "Nadia", "438-987-0000", "ROSO@gmail.com", spec1);
		
		Professeur prof3 = new Professeur("Alexannn", "Alexane", "438-987-1111", "ALEXAO@gmail.com", spec4);
		Professeur prof4 = new Professeur("Rosono", "Henrique", "438-987-9999", "ROSONO@gmail.com", spec4);
		
		
		Professeur prof5 = new Professeur("xxx1", "Henrique", "438-987-9999", "ROSONO@gmail.com", spec5);
		
		ArrayList<Professeur> profs = new ArrayList<Professeur> ();
		profs.add(prof4);
		profs.add(prof1);
		profs.add(prof2);
		profs.add(prof3);
	    profs.add(prof5);
	   
	   
	   ArrayList<Specialite> specialites = new ArrayList<Specialite> ();
	   
	   specialites.add(spec1);
	   specialites.add(spec2);
	   specialites.add(spec3);
	   specialites.add(spec4);
	   specialites.add(spec5);
	   
	   
	   for (Specialite spec : specialites) {
		   
		   
		  System.out.println(spec + " : ");
		   
	  
		  for(Professeur x : profs) {
				
				if(x.getSpec().equals(spec)) {
					
					
					System.out.println(x);
	   
	   
	   
	        }
		  }
	
	   
	   
		}

	
		
		
	}
	
}


