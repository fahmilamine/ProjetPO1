package Employes;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

public class TestEmployee {

	public static void main(String[] args) throws ParseException {
		
		int mat;
        String nom, prenom;
        LocalDate dn = null;
		LocalDate de = null;
        double salaire;

		    Scanner input = new Scanner(System.in);
	
		    
			System.out.println("Donner le matricule :");
			mat = input.nextInt();
			input.nextLine();
			System.out.println("Donner le nom : ");
			nom = input.nextLine();
			System.out.println("Donner le prenom : ");
			prenom = input.nextLine();
			System.out.println("Donner la date d'embauche  (M/d/yyyy) : ");
			String cinput = input.nextLine();
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("M/d/yyyy");
			 de = LocalDate.parse(cinput, dateFormat);
			 System.out.println("Donner la date de naissance  (M/d/yyyy) : ");
			 cinput = input.nextLine();
		     dn = LocalDate.parse(cinput, dateFormat);
			 System.out.println("Donner le salaire: ");
			 salaire = input.nextDouble();
		 
			 Employe e = new Employe(mat, nom, prenom, dn, de, salaire);
             e.AfficherEmploye();


	}

}
