package livres;

import java.util.ArrayList;
import java.util.Scanner;

import articles.Article;

public class TestLivre {

	public static void main(String[] args) {
		
		
		String titre, auteur;
		double prix;
		int compteur = 1;
		char reponse;
		
		Scanner input = new Scanner(System.in);
		ArrayList<Livre> livres = new ArrayList<Livre>();
		
		
		System.out.println("Voulez vous entrer les informations de votre livre (O)ui/(N)on");
		
		reponse = input.nextLine().toLowerCase().charAt(0);
		
		while(reponse == 'o') {
			
			System.out.println("Livre " + compteur);
			
			System.out.println("Donner le titre du livre:");
			titre = input.nextLine();
			
			System.out.println("Donner l'auteur du livre:");
			auteur = input.nextLine();
			
			System.out.println("Donner le prix du livre:");
			prix = input.nextDouble();
			
			
			System.out.println("Le titre est " + titre);
			System.out.println("L'auteur est " + auteur);
			System.out.println("Le prix " + prix);
			
			Livre liv = new Livre ();
			liv.setTitre(titre);
			liv.setAuteur(auteur);
			liv.setPrix(prix);
			
			System.out.println(liv);
			
			livres.add(liv);
			
			input.nextLine();
			
			System.out.println("Voulez vous entrer les informations de votre livre (O)ui/(N)on");
			
			reponse = input.nextLine().toLowerCase().charAt(0);
			compteur++;
			
		
				
			
			
		}
		
	
		
		//System.out.println(livres);
		
		
		
	
		
		
		

	}

}
