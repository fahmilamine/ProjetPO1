package heritage1;

public class TestRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	Rectangle r1 = new Rectangle ();
	Rectangle r2 = new Rectangle (12.5,25.5);
	Rectangle r3 = new Rectangle (15.5);
	
	
	System.out.println(r1);
	System.out.println(r2);
	System.out.println(r3);
	
	
	Caree c1 = new Caree (13.8);
	System.out.println(c1);
	
	RectangleVisible v1 = new RectangleVisible(12, 15, true);
	RectangleVisible v2 = new RectangleVisible(11, 18, false);
	
	System.out.println(v1);
	System.out.println(v2);
	
	
	
	}

}
