package heritage;

public class Compte {
	

protected int code;
protected float solde;
private static int nbComptes;

public Compte( ){

++nbComptes;
this.code=nbComptes;
this.solde=0;
}



public void verser(float mt){
solde+=mt;
}

public void retirer(float mt){
if(mt<solde) solde-=mt;
}

public String toString(){
return("Code="+code+" Solde="+solde);
}

}


