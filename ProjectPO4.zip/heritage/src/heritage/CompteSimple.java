package heritage;

public class CompteSimple extends Compte {
	
protected float decouvert;
protected  int limite;


//constructeur
public CompteSimple(float decouvert){
super();
this.decouvert=decouvert;
this.limite = 0;
 }

//constructeur
public CompteSimple(float decouvert, int limite){
super();
this.decouvert=decouvert;
this.limite = limite;
}



//Deuxi�me constructeur
public CompteSimple(){
this(0, 0);
}




@Override
public String toString() {
	return "CompteSimple [decouvert=" + decouvert + ", code=" + code + ", solde=" + solde + ", lmite=" + limite+"]";
}
















}

