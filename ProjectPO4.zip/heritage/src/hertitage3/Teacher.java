package hertitage3;

public class Teacher extends Person {
	
	private String subject;

	public Teacher(int age, String subject) {
		super(age);
		this.subject = subject;
	}
	
	public Teacher(int age) {
		super(age);
		
	}

	public void explain() {
		
		System.out.println("Explaination begins");
	}

	
	

}
