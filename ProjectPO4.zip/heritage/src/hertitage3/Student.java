package hertitage3;

public class Student extends Person {

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(int age) {
		super(age);
		// TODO Auto-generated constructor stub
	}

	public void DisplayAge() {
		
		System.out.println("My age is : " + age + " years old");
		
	}
	
	public void goToClasses() {
		
		System.out.println("I'm going to class");
	}

	@Override
	public String toString() {
		return "Student ["+super.toString() + "]";
	}
	
	
	
	
}
