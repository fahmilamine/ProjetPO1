package heritage2;

public class Avion extends Vehicule {

	private int nbMoteurs;
	private int helice;
	
	public Avion(double vitesse, int nbre_passagers, int nbMoteurs, int helice) {
		super(vitesse, nbre_passagers);
		this.nbMoteurs = nbMoteurs;
		this.helice = helice;
	}
	
public void affiche() {
		
		System.out.println("Vitesse : " + vitesse +" ,  Nb-Passager : " + nbre_passagers +"Nb-Moteurs : " + nbMoteurs +" ,  Nb-Helice : " + helice  );
	}
	
	
	
	
	
}
