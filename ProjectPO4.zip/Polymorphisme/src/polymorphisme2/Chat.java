package polymorphisme2;

public class Chat extends Animal {
	
	
	 public void crier() {
		    System.out.println("Miaouh ");
		  }
	 
	 public void crierxxxxxxx() {
		    System.out.println("xxxxxxx ");
		  }

}
