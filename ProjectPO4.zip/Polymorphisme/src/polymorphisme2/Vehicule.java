package polymorphisme2;

public class Vehicule {
	
	

	 public void crier() {
		    System.out.println("un v�hcule ne cri pas");
		  }


}
