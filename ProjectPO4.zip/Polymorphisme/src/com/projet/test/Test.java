package com.projet.test;

import com.projet.classes.Employe;
import com.projet.classes.Etudiant;
import com.projet.classes.Professeur;

public class Test {

	public static void main(String[] args) {
		
		
		Etudiant etud1 =  new Etudiant("Branchet", "Jean", "BJ487798557");
		Etudiant etud2 =  new Etudiant("Branchet", "Gabriel", "BG487798557");
		
		

		Employe emp1 =  new Employe("Bran", "JXC", 92500);
		Employe emp2 =  new Employe("Bran2", "JXC2", 85000);
		
		Professeur prof1 =  new Professeur("Alex1", "J66", 92500, "Info");
		Professeur prof2 =  new Professeur("Alex2", "Jkkl", 85000, "Science");
		
		
		
		System.out.println(etud1);
		System.out.println(etud2);
		
		System.out.println(emp1);
		System.out.println(emp2);
		
		System.out.println(prof1);
		System.out.println(prof2);

	}

}
