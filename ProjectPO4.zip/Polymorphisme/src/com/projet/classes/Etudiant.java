package com.projet.classes;

public class Etudiant extends Personne {
	
	private String cp;

	public Etudiant(String nom, String prenom, String cp) {
		super(nom, prenom);
		this.cp = cp;
	}

	public Etudiant(String cp) {
		super();
		this.cp = cp;
	}

	@Override
	public String toString() {
		return "Etudiant [cp=" + cp + ", toString()=" + super.toString() + "]";
	}
	
	
	

}
