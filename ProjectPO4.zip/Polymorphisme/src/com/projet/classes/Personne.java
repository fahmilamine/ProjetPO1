package com.projet.classes;

public abstract class Personne {
	
	protected int id;
	protected String nom, prenom;
	private static int compteur = 0;
	
	public Personne() {
		
		this.id = ++compteur;
		
	}
	
	public Personne(String nom, String prenom) {
		this.id = ++compteur;
		this.nom = nom;
		this.prenom = prenom;
	}



	@Override
	public String toString() {
		return "Personne [id=" + id + ", nom=" + nom + ", prenom=" + prenom + "]";
	}
	
	
	
	
	
	
	
	

}
