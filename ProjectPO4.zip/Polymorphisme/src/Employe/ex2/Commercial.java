package Employe.ex2;

public class Commercial extends Employee {
	
	
	private double vente;
	private double tauxComm;
	
	
	public Commercial(String nom, String matricule, double indiceSalaire, double vente, double tauxComm, double salaire) {
		super(nom, matricule, indiceSalaire, salaire);
		this.vente = vente;
		this.tauxComm = tauxComm;
	}
	
	
    public double calculerSalaire() {
		
		return (indiceSalaire*this.salaire) + vente*tauxComm;
		
	}


	public double getVente() {
		return vente;
	}


	public void setVente(double vente) {
		this.vente = vente;
	}


	public double getTauxComm() {
		return tauxComm;
	}


	public void setTauxComm(double tauxComm) {
		this.tauxComm = tauxComm;
	}


	@Override
	public String toString() {
		return "Commercial [vente=" + vente + ", tauxComm=" + tauxComm + ", salaire=" + this.calculerSalaire() + ", toString()="
				+ super.toString() + "]";
	}

	
	
    
	
	
	
	
	
	
	
	
	

}
