package polymorphisme1;

public class Orange extends Fruit{
public Orange(int p){
	
super(p);
poids=p;
System.out.println("cr�ation d'une Orange de "+ poids+" grammes ");
}
public void affiche(){
System.out.println("C'est une Orange");
}
public void affichePoids(){
System.out.println("le poids de la Orange est:"+poids+" grammes");
}
}
