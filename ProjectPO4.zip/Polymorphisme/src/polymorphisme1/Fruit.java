package polymorphisme1;

public abstract class Fruit{
int poids;
public Fruit(){
	super();
	System.out.println("Cr�ation d'un fruit : " + poids);
}



public Fruit(int poids) {
	super();
	this.poids = poids;
	System.out.println("Cr�ation d'un fruit : " + poids);
}



public void affiche(){
System.out.println("c'est un fruit");
}


public void affichePoids(){
System.out.println("le poids est propre au fruit");
}
}
