package prod;

public class LigneCmd {

String refArticle;
String nomArticlel;
double prixU;
int quantite;

public LigneCmd() {
	
}


public LigneCmd(String refArticle, String nomArticlel, double prixU, int quantite) {
	this.refArticle = refArticle;
	this.nomArticlel = nomArticlel;
	this.prixU = prixU;
	this.quantite = quantite;
}

public LigneCmd(String refArticle, String nomArticlel) {
	this.refArticle = refArticle;
	this.nomArticlel = nomArticlel;
}

public LigneCmd(String refArticle, String nomArticlel, double prixU) {
	this.refArticle = refArticle;
	this.nomArticlel = nomArticlel;
	this.prixU = prixU;
}


public double montant() {
	return this.prixU * this.quantite;
	
}







	
}
