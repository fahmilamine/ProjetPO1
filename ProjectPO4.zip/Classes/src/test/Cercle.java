package test;

public class Cercle {
	
	private Point centre;
	private double rayon;
	
	
	public Cercle() {
		this.rayon = 15;
	}



	public Cercle(Point centre, double rayon) {
		this.centre = centre;
		this.rayon = rayon;
	}



	public Point getCentre() {
		return centre;
	}



	public void setCentre(Point centre) {
		this.centre = centre;
	}
	
	
	
	/**/



	public double getRayon() {
		return rayon;
	}
	



	public void setRayon(double rayon) {
		this.rayon = rayon;
	}
	
	
	/*
	 * getPerimetre() : retourne le p�rim�tre du cercle
       getSurface() : retourne la surface du cercle.
       appartient(Point p) : retourne si le point p appartient ou non � l�int�rieur du cercle.
       toString() : retourne une cha�ne de caract�res de type CERCLE(x,y,R)

	 * 
	 * 
	 * 
	 * */
	
	public double getPerimetre() {
		
		return 2 * Math.PI * rayon;
	}
	
	
    public double getSurface() {
		
	return Math.PI * rayon * rayon;
	}

    public String toString() {
    	
    	return "CERCLE("+ centre.getX()+ ", "+centre.getY() + ", "+ this.rayon+" )" ; 
    			
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
		// champ priv� : rayon
		private double rayon;
		private Point centre;

		// un constructeur
		public Cercle(double r, Point p)
		{
			rayon = r;
			centre = p;
		}
		
		public Cercle(Point centre, Point p)
		{
			
			this.centre =centre;
			this.rayon = (p.getX()-centre.getX());
		}

	    // un autre constructeur
		public Cercle()
		{
			rayon = 12.345; // par  d�faut
		}

	    // calcul du p�rim�tre d'un cercle
		public double getPerimetre()
		{
			return 2 * Math.PI * rayon;
		}

	    // calcul de la surface d'un cercle
		public double getSurface()
		{
			return Math.PI * rayon * rayon;
		}

	    // afficher les informations d'un cercle
		public void afficher(String message)
		{
			System.out.printf("%s : %7.1f %10.2f %8.2f\n", message, rayon, getPerimetre(), getSurface());
		}

		// m�thode d'acc�s
		public double getRayon()
		{
			return rayon;
		}

		// m�thode de modification
		public void setRayon(double nouvRayon)
		{
			rayon = nouvRayon;
		}

		public Point getCentre() {
			return centre;
		}

		public void setCentre(Point centre) {
			this.centre = centre;
		}
		


		@Override
		public String toString() {
			return "CERCLE ("+centre.getX()+", " +centre.getY()+", " + rayon + ")";
		}
	

*/

}




