package test;

import prod.Compte;

public class Principale {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
    
//	Compte c2 = new Compte();
//	Compte c3 = new Compte();
/*	Compte c1 = new Compte (100, 2000);
	Compte c2 = new Compte (110, 3000);
	Compte c3 = new Compte (120, 6000);
	Compte c4 = new Compte();
	c4.setCode(130);
	c4.setSolde(8000);
	*/
	
	/*LigneCmd l1 = new LigneCmd();
	LigneCmd l2 = new LigneCmd("X1123", "Table");
	LigneCmd l3 = new LigneCmd("X1124", "Chaise", 66.99,4);
	LigneCmd l4 = new LigneCmd("X1125", "T�l�", 999.99, 2);*/
	
	/*System.out.println("Le montant de la chaise : " +l3.montant());
	System.out.println("Le montant de la T�l� : " +l4.montant());*/
	
	
	/*
	
	System.out.println(c1);
	System.out.println(c2);
	System.out.println(c3);
	System.out.println(c4);
	*/
	
	/*a. Cr�er un cercle d�fini par le centre c(100,100) et un point p(200,200)
b. Cr�er un cercle d�fini par le centre c(130,100) et de rayon r=40
c. Afficher le p�rim�tre et le rayon des deux cercles.
d. Afficher si le point p(120,100) appartient � l�intersection des deux cercles ou non
	 * 
	 * 
	 * */
	
	/*	
		Cercle c1 = new Cercle (40, new Point(130,100));
		System.out.println(c1);
		System.out.println(c1.getPerimetre());
		System.out.println(c1.getRayon());
		
		
		Cercle c2 =new Cercle (new Point(100,100), new Point(200,200));
		
		System.out.println(c2);
		System.out.println(c2.getPerimetre());
		System.out.println(c2.getRayon());
		*/
		
		
		
		
		Cercle c1 = new Cercle(new Point(100,100), 45.4);
		System.out.println(c1);
	
	
	}

}
