package javapartie3;

public class AffichageNombre {
	
	

	static void afficher(int nombre)
	{
      for(int fin = 1 ; fin <= nombre ; fin += 2)
      {
      	for(int debut = nombre; debut >= fin ; debut -= 2)
      		 System.out.printf("%3d ", debut);
      	System.out.printf("\n");
      }

      	      System.out.printf("\n");

	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		   final int NOMBRE1 =  9,
		             NOMBRE2 =  5;

		   afficher(NOMBRE1);
		   afficher(NOMBRE2);

	
	
	}

}
