package javapartie3;

public class StatCafe {
	
	
	//-	la consommation minimale de caf� de tous ces employ�s
	
	static void consommationMinTous(char[] poste, int[] nbCafe){
		int min = nbCafe[0];

        for (int j : nbCafe) {
            if (j < min)
                min = j;
        }
        
        System.out.printf("Consommation minimale caf�          : %d tasse(s)par jour\n", min);

		
	}
	
	static void consommationMaxOps(char[] poste, int[] nbCafe){
		int max = Integer.MIN_VALUE;

        for (int i =0; i<poste.length; i++) {
            if (poste[i]=='O')
                if(nbCafe[i]>= max) {
                	max = nbCafe[i];
                }
    }
        
        System.out.printf("Consommation maximale caf� des op�rateurs         : %d tasse(s)par jour\n", max);

		
	}

	
	static void consommationMoyAnalystes(char[] poste, int[] nbCafe){
		double somme = 0;
		int compteur = 0;
		double moyenne=0;

        for (int i =0; i<poste.length; i++) {
            if (poste[i]=='A'){
            	 somme+=nbCafe[i];
                	compteur++;
                }
    }
        moyenne = somme/compteur;
        System.out.printf("Consommation moyenne caf� des analystes         : %f tasse(s)par jour\n", moyenne);

		
	}
	
	static void consommationMoyProgs(char[] poste, int[] nbCafe){
		double somme = 0;
		int compteur = 0;
		double moyenne=0;

        for (int i =0; i<poste.length; i++) {
            if (poste[i]=='P'){
            	 somme+=nbCafe[i];
                	compteur++;
                }
    }
        if(compteur>0)
        moyenne = somme/compteur;
        System.out.printf("Consommation moyenne caf� des programmeurs        : %f tasse(s)par jour\n", moyenne);

		
	}
	
	
	static void consommationMoySecs(char[] poste, int[] nbCafe){
		double somme = 0;
		int compteur = 0;
		double moyenne=0;

        for (int i =0; i<poste.length; i++) {
            if (poste[i]=='S'){
            	 somme+=nbCafe[i];
                	compteur++;
                }
    }
       if(compteur>0)
        moyenne = somme/compteur;
        System.out.printf("Consommation moyenne caf� des secreteurs        : %f tasse(s)par jour\n", moyenne);

		
	}
	
	
	static void consommationMoy(char[] poste, int[] nbCafe, char x){
		double somme = 0;
		int compteur = 0;
		double moyenne=0;

        for (int i =0; i<poste.length; i++) {
            if (poste[i]==x){
            	 somme+=nbCafe[i];
                	compteur++;
                }
    }
        moyenne = somme/compteur;
        System.out.printf("Consommation moyenne caf�          : %f tasse(s)par jour\n", moyenne);

		
	}
	
	static void consommationCafe(char[] poste, int[] nbCafe, char x, int seuil, String pos){
		double somme = 0;
		int compteur = 0;
		double moyenne=0;

        for (int i =0; i<poste.length; i++) {
            if (poste[i]==x){
            	 if(nbCafe[i]>seuil)
                	compteur++;
                }
    }
        moyenne = somme/compteur;
        System.out.printf("%d %s consomment: plus de %x tasse(s)par jour\n", compteur,pos, seuil);

		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char[] poste = { 'P', 'A', 'O', 'A', 'P', 'A', 'P', 'P' , 'O'}; 
		int[] nbCafe = { 3, 2, 4, 0, 4, 2, 5, 8, 1 };
		int nbEmp = poste.length ;
		
		//la consommation minimale de caf� de tous ces employ�s
		consommationMinTous(poste, nbCafe);
		
		//la consommation maximale de caf� des op�rateurs
		 consommationMaxOps(poste, nbCafe);
		 
		 //	la consommation moyenne de caf� des analystes
		 consommationMoyAnalystes(poste, nbCafe);
		 
		 //la consommation moyenne de caf� des programmeurs
		 consommationMoyProgs(poste, nbCafe);
		 
		 //la consommation moyenne de caf� des secr�taires
		 consommationMoySecs(poste, nbCafe);
		 
		 //--------------------------------
		 consommationMoy(poste, nbCafe, 'A');
		 
		 
		 //
		 consommationCafe(poste, nbCafe, 'A', 3 , "Analystes");
		 consommationCafe(poste, nbCafe, 'P', 1 , "Programmeurs");
		 
		 
		 
		 

	/*
	 * -	d�analystes consommant plus de 3 tasses de caf� par jour
-	de programmeurs buvant de caf� (1 tasse ou plus)

	 * */
	
	}

}
