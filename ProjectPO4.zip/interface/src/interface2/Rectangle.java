package interface2;

public class Rectangle implements CalculGeometrique {
	
	private double largeur;
	private double longueur;
	
	
	public Rectangle(double largeur, double longueur) {
		super();
		this.largeur = largeur;
		this.longueur = longueur;
	}


	public double getLargeur() {
		return largeur;
	}


	public void setLargeur(double largeur) {
		this.largeur = largeur;
	}


	public double getLongueur() {
		return longueur;
	}


	public void setLongueur(double longueur) {
		this.longueur = longueur;
	}


	@Override
	public String toString() {
		return "Rectangle [largeur=" + largeur + ", longueur=" + longueur + "]";
	}


	@Override
	public double surface() {
	
		return this.largeur  * this.longueur ;
	}


	@Override
	public double perimetre() {
		
		return 2 * (this.longueur +this.largeur);
	}
	
	
	
	
	
	

}
