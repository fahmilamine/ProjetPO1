package interface1;

public interface Comparable {
	
	public abstract boolean plusPetit(Object obj);
	

}
