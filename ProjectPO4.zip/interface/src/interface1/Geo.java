package interface1;

public class Geo extends Object implements uneinterface{
	
	
	public int test1() { 
		
		
		
		return 0;}
	public int test2() {return 0;}
	public int test4() {return 0;}
	public int test5() {return 0;}
	public int test3() {return 0;}

}
