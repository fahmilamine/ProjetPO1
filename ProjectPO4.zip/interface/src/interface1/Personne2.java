package interface1;

public class Personne2 implements Comparable
{ private double taille, poids;
 private char sexe ;
 public Personne2(double t, double p, char s) {
 taille = t ;
 poids = p;
 sexe = s;
 }

 public double getTaille(){
 return taille;
 }

 public char getSexe(){
 return sexe;
 }

 public String toString() {
 return sexe + " mesure " + taille + " metre et pese " + poids +
 " kgs";
 }
 // On s'engage � impl�menter la m�thode "plusPetit" :
 public boolean plusPetit(Object p) {
 return this.taille < ( (Personne2) p).getTaille();
 }
 
}