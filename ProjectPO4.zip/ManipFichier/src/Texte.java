import java.io.*;

public class Texte
{	


       static int lireRemplir(String nomFichier, char[] sexe, int[] numero,
                                          double[] taille, double[] poids)
		           throws IOException
        {
          boolean existeFichier = true ; //  ajuster apres
          int n = 0;

          FileReader fr = null; // initialiser pour Java

           // essayer de LOCALISER le fichier a partir de son nom
           try {
                     fr = new FileReader (nomFichier) ;
           }
           // intercepter l'erreur si le fichier n'existe pas
           catch ( java.io.FileNotFoundException erreur) {
              System.out.println("Probleme d'ouvrir le fichier " +
                 nomFichier);
              existeFichier = false ; // ajuster
           }

           if (existeFichier) {

             // construire l'objet d'entr�e qui va permettre
             // d'appliquer la lecture d'une ligne de texte

			 BufferedReader entree = new BufferedReader(fr);
             boolean finFichier = false ;

			 while ( !finFichier ) {

             // lire une ligne
               String uneLigne = entree.readLine();


				if (uneLigne == null)
				             finFichier = true ;
				else {

				   //01234567890123456789
				   //F  2187  5  6  180
                   //F  4148  5 11  185
				   sexe[n] = uneLigne.charAt(0);
				   numero[n] = Integer.parseInt(uneLigne.substring(3,7).trim());
				   int nbPieds = Integer.parseInt(uneLigne.substring(9,10).trim()),
				       nbPouces= Integer.parseInt(uneLigne.substring(11,13).trim()),
				       nbLivres= Integer.parseInt(uneLigne.substring(15,18).trim());
				   
				   

				   final double PIED_EN_METRE = 0.3048,
				                LIVRE_EN_KG   = 0.454;

				   taille[n] = (nbPieds+nbPouces/12.0)*PIED_EN_METRE;
				   poids[n]  = nbLivres * LIVRE_EN_KG;
                   n++;
   	            }
               }
             entree.close();

          }
        return n;
    }



static void afficher(char[] sexe, int[] numero, double[] taille,
                       double[] poids, int nbPers, String mess)

{
	System.out.printf("Contenu des 4 tableaux %s :\n", mess);
	for(int i = 0; i < nbPers; i++)
		System.out.printf("%3d) %5c %8d %10.2f %8.1f\n", i, sexe[i],
		     numero[i], taille[i], poids[i]);
    System.out.printf("\n");
}

static void determinerMinMax(double[] tableau, int nbElem, char code)
{
    double mini = Double.MAX_VALUE, maxi = Double.MIN_VALUE;
    for(int i = 0; i < nbElem ; i++)
    {
    	if (tableau[i] < mini)mini = tableau[i];
    	if (tableau[i] > maxi)maxi = tableau[i];
    }

    if(code == 't')
    	System.out.printf("\nLa taille minimale : %.2f metre\n" +
    		              "La taille maximale : %.2f metre\n", mini, maxi);
    else
    	System.out.printf("\nLe poids  minimal  : %.1f kg\n" +
    		              "Le poids maximum   : %.1f kg\n", mini, maxi );
}

static void permuter(char[] sexe, int i, int indMin)
{
	char tempo = sexe[i];
	sexe[i]    = sexe[indMin];
	sexe[indMin] = tempo;
}

static void permuter(int[] numero, int i, int indMin)
{
	int tempo = numero[i];
	numero[i]    = numero[indMin];
	numero[indMin] = tempo;
}

static void permuter(double [] tab, int i, int indMin)
{
	double tempo = tab[i];
	tab[i]    = tab[indMin];
	tab[indMin] = tempo;
}


static void trier(char[] sexe, int [] numero, double[] taille,
                           double[] poids, int nbPers)
{
	for(int i = 0; i < nbPers-1; i++)
	{
		int indMin = i;
		for(int j = i+1; j < nbPers; j++)
			if (numero[j] < numero[indMin])
				  indMin = j;
        if (indMin != i)
        {
        	permuter(sexe, i, indMin);
        	permuter(numero, i, indMin);
        	permuter(taille, i, indMin);
        	permuter(poids, i, indMin);
        }
	}
}

public static void main (String[] args)
		throws IOException
	{
	   final int MAX_PERS = 25 ; // au maximum 25 personnes
	   char[] sexe = new char[MAX_PERS];
	   int [] numero = new int [MAX_PERS];
	   double[] taille = new double [MAX_PERS],
                poids  =  new double [MAX_PERS];

	   int nbPers = lireRemplir("imp_h15.txt", sexe, numero, taille, poids);
	   afficher(sexe, numero, taille, poids, nbPers, "apres la lecture");

	   determinerMinMax(taille, nbPers, 't');
	   determinerMinMax(poids , nbPers, 'p');

	   trier(sexe, numero, taille, poids, nbPers);
	   afficher(sexe, numero, taille, poids, nbPers, "apres le tri selon les num�ros");

      	}
}
