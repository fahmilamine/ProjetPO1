package clients;

public class TestCompte {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	Client cl1 = new Client("POAS122354", "Chabi", "Nathalie", "438-987-6969"); 
	Client cl2 = new Client("POAS122366", "Fahmi", "Amine", "514-999-6969"); 
		
	Compte c = new Compte(cl1);
	Compte c2 = new Compte(cl2);
	
	System.out.println(c);
	
	c.crediter(5000);
	
	c.crediter(2000, c2);
	
	c.debiter(1500);
	
	c.debiter(3000, c2);
	
	
	System.out.println(c);
	System.out.println(c2);
	
	Compte.afficherNbComptes();
	
	/*Compte c2 =new Compte();
	c.crediter(2333.33);
	c.crediter(1000, c2);*/
	
	
	}

}
