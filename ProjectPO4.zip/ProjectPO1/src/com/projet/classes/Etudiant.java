package com.projet.classes;

import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;

public class Etudiant {

private int id;
private String nom, prenom;
private LocalDate DateNaissaince;
private Filiere fel;
public static int compteur = 0;


public Etudiant() {
	super();
	this.id = ++compteur;
	// TODO Auto-generated constructor stub
}


public Etudiant(String nom, String prenom, LocalDate dateNaissaince, Filiere fel) {
	super();
	this.id = ++compteur;
	this.nom = nom;
	this.prenom = prenom;
	DateNaissaince = dateNaissaince;
	this.fel = fel;
}


public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


public String getNom() {
	return nom;
}


public void setNom(String nom) {
	this.nom = nom;
}


public String getPrenom() {
	return prenom;
}


public void setPrenom(String prenom) {
	this.prenom = prenom;
}


public LocalDate getDateNaissaince() {
	return DateNaissaince;
}


public void setDateNaissaince(LocalDate dateNaissaince) {
	DateNaissaince = dateNaissaince;
}







public Filiere getFel() {
	return fel;
}


public void setFel(Filiere fel) {
	this.fel = fel;
}


@Override
public String toString() {
	return "Etudiant [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", DateNaissaince=" + DateNaissaince
			+ ", fel=" + fel + "]";
}











}














