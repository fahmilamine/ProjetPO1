package com.projet.classes;

import java.util.Objects;

public class Filiere {

private int id;
private String code, libelle;
public static int compteur = 0;

public Filiere() {
	super();
	this.id = ++compteur;
	
	// TODO Auto-generated constructor stub
}

public Filiere(String code, String libelle) {
	super();
	this.id = ++compteur;
	this.code = code;
	this.libelle = libelle;
}

public String getCode() {
	return code;
}

public void setCode(String code) {
	this.code = code;
}

public String getLibelle() {
	return libelle;
}

public void setLibelle(String libelle) {
	this.libelle = libelle;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

@Override
public String toString() {
	return "Filiere [id=" + id + ", code=" + code + ", libelle=" + libelle + "]";
}

@Override
public int hashCode() {
	return Objects.hash(id);
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Filiere other = (Filiere) obj;
	return id == other.id;
}








}
