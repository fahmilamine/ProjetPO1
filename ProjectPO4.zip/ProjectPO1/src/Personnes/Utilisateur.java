package Personnes;

public class Utilisateur extends Personne {
	
	private String login;
	private String password;
	private String service;
	private Profil profil;
	
	
	public Utilisateur(String login, String password, String service, Profil profil) {
		super();
		this.login = login;
		this.password = password;
		this.service = service;
		this.profil = profil;
	}


	public Utilisateur(String nom, String prenom, String mail, String telephone, double salaire, String login,
			String password, String service, Profil profil) {
		super(nom, prenom, mail, telephone, salaire);
		this.login = login;
		this.password = password;
		this.service = service;
		this.profil = profil;
	}
	
	public double calculerSalaire() {
		
		if(this.profil.getCode().equalsIgnoreCase("MN")) {
			
			return 1.1 * this.salaire;
		}else if(this.profil.getCode().equalsIgnoreCase("DG")) {
			
			return 1.4 * this.salaire;
		}else
			return this.salaire;
	
	}
	
	public void afficher() {
		
		System.out.println( "Utilisateur [login=" + login + ", password=" + password + ", service=" + service + ", profil=" + profil.getCode()
		+ ", id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", mail=" + mail + ", telephone=" + telephone
		+ ", salaire=" + this.calculerSalaire() + "]");
		
	}


	public String getLogin() {
		return login;
	}


	public void setLogin(String login) {
		this.login = login;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getService() {
		return service;
	}


	public void setService(String service) {
		this.service = service;
	}


	public Profil getProfil() {
		return profil;
	}


	public void setProfil(Profil profil) {
		this.profil = profil;
	}
	
	

	
	
	
	
	
	
	
	
	
	
	
	

}
