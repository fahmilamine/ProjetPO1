package Employes;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

public class Employe {


	private int matricule;
    private String nom;
    private String prenom;
    private LocalDate datenaissance;
    private LocalDate dateembauche;
    private double salaire;
	
    
    public Employe() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Employe(int matricule, String nom, String prenom, LocalDate datenaissance, LocalDate dateembauche, double salaire) {
		super();
		this.matricule = matricule;
		this.nom = nom;
		this.prenom = prenom;
		this.datenaissance = datenaissance;
		this.dateembauche = dateembauche;
		this.salaire = salaire;
	}


	public int getMatricule() {
		return matricule;
	}


	public void setMatricule(int matricule) {
		this.matricule = matricule;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getPrenom() {
		return prenom;
	}


	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}


	public LocalDate getDatenaissance() {
		return datenaissance;
	}


	public void setDatenaissance(LocalDate datenaissance) {
		this.datenaissance = datenaissance;
	}


	public LocalDate getDateembauche() {
		return dateembauche;
	}


	public void setDateembauche(LocalDate dateembauche) {
		this.dateembauche = dateembauche;
	}


	public double getSalaire() {
		return salaire;
	}


	public void setSalaire(double salaire) {
		this.salaire = salaire;
	}


	@Override
	public String toString() {
		return "Employe [matricule=" + matricule + ", nom=" + nom + ", prenom=" + prenom + ", datenaissance="
				+ datenaissance + ", dateembauche=" + dateembauche + ", salaire=" + salaire + "]";
	}
    
    
	

    public int Age()
    {
        int age;
        int now = LocalDateTime.now().getYear();
        age = now - datenaissance.getYear();
        return age;


    }

    public int Anciennete()
    {
        int Anc;
        Anc = LocalDateTime.now().getYear()  - dateembauche.getYear();
        return Anc;

    }

	
	 public void AugmentationDuSalaire()
     {
         if (Anciennete() < 5)
             salaire += salaire * 0.02;
         else if (Anciennete() < 10)
             salaire += salaire * 0.05;
         else
             salaire += salaire * 0.1;
     }

     public void AfficherEmploye()
     {
       System.out.println("\n\nMatricule : " + matricule);
       System.out.println("Nom Complet : " + nom+ " " + prenom);
       System.out.println("Age : " + Age());
       System.out.println("Anciennet� : " + Anciennete());
       System.out.println("Salaire : " + salaire);
     }


    
    
    

}
