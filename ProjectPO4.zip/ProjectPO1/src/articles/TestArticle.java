package articles;

import java.util.ArrayList;
import java.util.Scanner;

public class TestArticle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String designation, reference;
		double prixHT;
		
		
		ArrayList<Article> articles = new ArrayList<Article>();
		Article arc;
		Scanner input = new Scanner(System.in);
		System.out.println("Donner le taux de TVA pour tous les articles :");
		Article.TAUX_TVA = input.nextInt();
		System.out.println("Le taux TVA est:" + Article.TAUX_TVA+"%");
		input.nextLine();
	
		System.out.println("Voulez vous entrer un article (O)ui/(N)on");
		char reponse =  input.nextLine().charAt(0);
		while(reponse=='O') {
	    input.nextLine();
		System.out.println("Donner la designation :");
		designation = input.nextLine();
		System.out.println("Donner la reference : ");
		reference = input.nextLine();
		System.out.println("Donner le prix hors tax :");
		prixHT = input.nextInt();
		input.nextLine();
		arc = new Article(designation, reference, prixHT);
		articles.add(arc);
		
		System.out.println("Voulez vous entrer un article (O)ui/(N)on");
		reponse =  input.nextLine().charAt(0);
			
		
		}
		
		
		
		//System.out.println(articles);
		
		for(int i = 0; i< articles.size(); i++) {
			
			System.out.println(articles.get(i));
		}
		//Article arc = new Article(designation, reference, prixHT);
		//System.out.println(arc.afficherArticle());
		//input.nextLine();
	
		
		
		
		
		
		
		
		
	/*
	Article ar1 = new Article();
	ar1.setReference("X599874");
	ar1.setDesignation("Frigo");
	ar1.setPrixHT(1599);
	Article ar2 = new Article("X144785", "T�l�vision", 299);
	Article ar3 = new Article("X599872", "Ordinateur");
	ar3.setPrixHT(899);
	
	System.out.println (ar1.calculerPrixTTC());
	System.out.println (ar2.calculerPrixTTC());
	System.out.println (ar3.calculerPrixTTC());
	*/
	
	}

}
