package articles;

public class Article {
	
	private String reference, designation;
	private double prixHT;
	static double TAUX_TVA;
	static int compteur =0;
	
	
	//Constructeurs
	
	
	public Article() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public Article(String reference, String designation, double prixHT) {
		super();
		//this.id =++compteur;
		this.reference = reference;
		this.designation = designation;
		this.prixHT = prixHT;
	}
	
	




	public Article(String reference, String designation) {
		super();
		this.reference = reference;
		this.designation = designation;
	}




	// Getters et setters
	
	public String getReference() {
		return reference;
	}
	
	public void setReference(String reference) {
		this.reference = reference;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getPrixHT() {
		return prixHT;
	}
	public void setPrixHT(double prixHT) {
		this.prixHT = prixHT;
	}
	
	// M�thodes
	
	double calculerPrixTTC(){
		
		return prixHT + (prixHT*TAUX_TVA/100);
	}




	
	public String toString() {
		return "Article [reference=" + reference + ", designation=" + designation + ", prixHT=" + prixHT +", prixTT=" + calculerPrixTTC() +"]";
	}
	

	
	

//R�f�rence, Designation, PrixHT, TauxTVA.



}
