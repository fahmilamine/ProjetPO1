package ExceptionExos;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exo1Q2 {


		
		
		@SuppressWarnings("resource")
		static void saisieCorrect() throws InputException{
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Donnez un entier : ");
			int nombre = sc.nextInt();
			
			if(nombre < 10) throw new InputException("La valeur est plus petite que 10");
			System.out.println("L'entier saisi est : " + nombre);
			sc.close();
			
			
		}

		public static void main(String[] args) {
			
			while(true) {
				
				
			try {
			saisieCorrect();
			break;

			
			}catch(InputException e){
				
				System.out.println(e.getMessage());
			
			}catch(InputMismatchException e){
				
				System.out.println("Erreur de saisie !!");
			}finally {
				
				
				System.out.println("Fin");
			}
			
			}
		}

	}


