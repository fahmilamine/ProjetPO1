package ExceptionExos;

public class FiboException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FiboException(String message) {
		super(message);
		
	}
	


}
