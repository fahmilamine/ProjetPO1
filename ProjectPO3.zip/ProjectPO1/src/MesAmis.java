import java.util.Scanner;

public class MesAmis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String nom, prenom;
		int age;
		
		Scanner input = new Scanner(System.in);
		System.out.println("Quel est votre nom ?");
		nom = input.nextLine();
		System.out.println("Quel est votre prenom ?");
		prenom = input.nextLine();
		System.out.println("Quel est votre age ?");
		age = input.nextInt();
		

		
	    Personne unTel = new Personne(nom, prenom, age);
	    
	    input.nextLine();
	    
	    System.out.println("Quel est votre nom ?");
		nom = input.nextLine();
		System.out.println("Quel est votre prenom ?");
		prenom = input.nextLine();
		System.out.println("Quel est votre age ?");
		age = input.nextInt();
		
		Personne unTel2 = new Personne(nom, prenom, age);
		
		
	    if(unTel.equals(unTel2))
	        System.out.println("Les objets sont les memes");
	    else
	        System.out.println("Les objets sont differents");
	  
	    
	   
	
	
	
	
	}

}
