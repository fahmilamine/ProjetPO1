package clients;

public class Compte {

private double solde;
private int code;
private Client proprio;
static int compteur = 0;





// constructeurs
public Compte() {
	this.code = ++compteur;
}



public Compte(Client proprio) {
	this.code = ++compteur;
	this.proprio = proprio;
}



//Getters et setters
public double getSolde() {
	return solde;
}

public int getCode() {
	return code;
}

public Client getProprio() {
	return proprio;
}
public void setProprio(Client proprio) {
	this.proprio = proprio;
}
public static int getCompteur() {
	return compteur;
}
public static void setCompteur(int compteur) {
	Compte.compteur = compteur;
}


//Fonctions


public void crediter (double som) {
	
	this.solde = this.solde + som;
	System.out.println(" Operation d'ajout a reussie ");
		
}


public void crediter (double som, Compte c) {
	
	if(c.solde>=som) {
	   
		c.solde -= som;
		
		//crediter(som);
		this.solde +=som;
		System.out.println(" Operation de debiter et crediter reussie ");
	
	}else {
		
		System.out.println(" Impossible d'effectuer l'operation (Compte insuffisant) ");
		
	}
	
}


public void debiter (double som) {
	
	this.solde = this.solde - som;
	System.out.println(" Operation d'ajout a reussie ");
		
}


public void debiter (double som, Compte c) {
	
	if(this.solde>=som) {
		   
		this.solde -= som;
		
		//crediter(som);
		c.solde +=som;
		System.out.println(" Operation de debiter et crediter reussie ");
	
	}else {
		
		System.out.println(" Impossible d'effectuer l'operation (Compte courant insuffisant) ");
		
	}
		
}



@Override
public String toString() {
	return "Compte [solde=" + solde + ", code=" + code + ", proprio=" + proprio.afficher() + "]";
}

public static void afficherNbComptes() {
	System.out.println(" Le nombre de comptes crees = " +compteur);
	
}


















}
