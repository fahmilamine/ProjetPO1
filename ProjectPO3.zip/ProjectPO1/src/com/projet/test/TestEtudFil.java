package com.projet.test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import com.iti.ecole.Professeur;
import com.iti.ecole.Specialite;
import com.projet.classes.Etudiant;
import com.projet.classes.Filiere;

public class TestEtudFil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	

	
	
	Filiere spec1 = new Filiere("RO420", "Informatique");
	Filiere spec2 = new Filiere("RO421", "Finance");
	Filiere spec3 = new Filiere("RO422", "Commerce");
	Filiere spec4 = new Filiere("RO423", "Science");
	
	
	
	Etudiant etu1 =  new Etudiant("Alex1","Alex1",LocalDate.of(1984, 12, 03),spec1);
	Etudiant etu2 =  new Etudiant("Alex2","Alex2",LocalDate.of(1984, 12, 03), spec2);
	Etudiant etu3 =  new Etudiant("Alex3","Alex3",LocalDate.of(1984, 12, 03), spec3);
	Etudiant etu4 =  new Etudiant("Alex4","Alex4",LocalDate.of(1984, 12, 03), spec4);
	Etudiant etu5 =  new Etudiant("Alex5","Alex5",LocalDate.of(1984, 12, 03),spec4);
	
	
	ArrayList<Etudiant> etudiants = new ArrayList<Etudiant> ();
	etudiants.add(etu4);
	etudiants.add(etu1);
	etudiants.add(etu2);
	etudiants.add(etu3);
	etudiants.add(etu5);
   
   
   ArrayList<Filiere> filieres = new ArrayList<Filiere> ();
   
   filieres.add(spec1);
   filieres.add(spec2);
   filieres.add(spec3);
   filieres.add(spec4);
  
   
   
   for (Filiere fel : filieres) {
	   
	   
		  System.out.println(fel + " : ");
		   
	  
		  for(Etudiant x : etudiants) {
				
				if(x.getFel().equals(fel)) {
					
					
					System.out.println(x);
	   
	   
	   
	        }
		  }
	
	
	
	}


	}}
