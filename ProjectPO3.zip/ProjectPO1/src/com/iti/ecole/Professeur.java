package com.iti.ecole;

public class Professeur {


private int id;
private String nom, prenom, telephone, email;
private Specialite spec;
static int compteur = 0;


public Professeur() {
	this.id = ++compteur;
}


public Professeur(String nom, String prenom, String telephone, String email, Specialite spec) {
	
	this.id = ++compteur;
	this.nom = nom;
	this.prenom = prenom;
	this.telephone = telephone;
	this.email = email;
	this.spec = spec;
}


public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


public String getNom() {
	return nom;
}


public void setNom(String nom) {
	this.nom = nom;
}


public String getPrenom() {
	return prenom;
}


public void setPrenom(String prenom) {
	this.prenom = prenom;
}


public String getTelephone() {
	return telephone;
}


public void setTelephone(String telephone) {
	this.telephone = telephone;
}


public String getEmail() {
	return email;
}


public void setEmail(String email) {
	this.email = email;
}


public Specialite getSpec() {
	return spec;
}


public void setSpec(Specialite spec) {
	this.spec = spec;
}


@Override
public String toString() {
	return "Professeur [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", telephone=" + telephone + ", email="
			+ email + ", spec=" + spec + "]";
}





}







