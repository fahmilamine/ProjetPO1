package Voitures;

import java.util.Date;

public class TestVoiture {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		Voiture v1 = new Voiture (200, 260, "Audi");
		Voiture v2 = new Voiture (220, 270, "Tesla");
		Voiture v3 = new Voiture (225, 270, "Kia");
		Voiture v4 = new Voiture (240, 270, "BMW");
		Voiture v5 = new Voiture (298, 270, "SUBARU");
		
		
		System.out.println(v1);
		
		System.out.println(v2);
		
		System.out.println(v3);
		
		System.out.println(v4);
		
		
		System.out.println(v5);

	}

}
