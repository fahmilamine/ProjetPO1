package prod;  

public class Compte {

	// Attributs  
private int code;
private double solde;

public int getCode() {
	return code;
}

public void setCode(int code) {
	this.code = code;
}

public double getSolde() {
	return solde;
}

public void setSolde(double solde) {
	this.solde = solde;
}



//Constructeur par d�fault
public Compte(){  
	
}

// Constructeur
public Compte(int c,double s){  
	
	code=c; 
	solde=s;
}
// M�thode pour verser un montant  

public void verser(double mt){
solde+=mt;
}
// M�thode pour retirer un montant  

public void retirer(double mt){
solde-=mt;
}
// Une m�thode qui retourne l'�tat du compte  

public String toString(){
return(" Code="+code+" Solde="+solde);
}

}