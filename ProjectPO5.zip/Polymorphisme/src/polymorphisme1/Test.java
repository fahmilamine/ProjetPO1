package polymorphisme1;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Pomme p=new Pomme(72);
		//Orange o=new Orange(80);
		
		
		Fruit f1;
		Fruit f2;
		f1=new Pomme(60);
		f2=new Orange(40);
		f1.affiche();//((Pomme)f1).affiche();
		f2.affiche();
		f1.affichePoids();
		f2.affichePoids();

		
	}

}
