package polymorphisme2;

public class Animal {
	
	
	 public void crier() {
		    System.out.println("un cri d'animal");
		  }

}
