package polymorphisme2;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Object obj = new Object();
		
		Vehicule vec1 = new Vehicule();
		Animal animal = new Animal();
		
		obj =vec1;
		obj = animal;
		animal.crier(); // affiche "un cri d'animal"

		Chat chat = new Chat();
		chat.crier();   // affiche "Miaou !"
		chat.crierxxxxxxx();

		Chien chien = new Chien();
		chien.crier();  // affiche "Whouaf whouaf !"

		animal = chat;
		animal.crier(); // affiche "Miaou !"
		animal.crier();

		animal = chien;
		animal.crier(); // 

	}

}
