package com.projet.classes;

public class Professeur extends Employe {
	
	
	private String specialite;

	
	public Professeur(String nom, String prenom, double salaire, String specialite) {
		super(nom, prenom, salaire);
		this.specialite = specialite;
	}


	public Professeur(String nom, String prenom, String specialite) {
		super(nom, prenom);
		this.specialite = specialite;
	}


	@Override
	public String toString() {
		return "Professeur [specialite=" + specialite + ", toString()=" + super.toString() + "]";
	}
	
	
	
	
	
	

}
