package com.projet.classes;

public class Employe extends Personne {
	
	
	protected double salaire;

	public Employe(String nom, String prenom, double salaire) {
		super(nom, prenom);
		this.salaire = salaire;
	}

	public Employe(double salaire) {
		super();
		this.salaire = salaire;
	}

	public Employe() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employe(String nom, String prenom) {
		super(nom, prenom);
	
	}

	@Override
	public String toString() {
		return "Employe [salaire=" + salaire + ", toString()=" + super.toString() + "]";
	}
	
	
	
	
	
	
	
	
	
	
	

}
