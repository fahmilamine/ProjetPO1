package Employe.ex2;

import java.util.ArrayList;

public class Responsable extends Employee {
	
	
	ArrayList<Employee> liste = new ArrayList<Employee>();

	public Responsable(String nom, String matricule, double salaire, double indiceSalaire, ArrayList<Employee> liste) {
		super(nom, matricule, indiceSalaire, salaire);
		this.liste = liste;
	}

	@Override
	public String toString() {
		return "Responsable [liste=" + liste + ", calculerSalaire()=" + calculerSalaire() + ", toString()="
				+ super.toString() + "]";
	}
	
	
}
