package Employe.ex2;

public class Employee {
	
	protected String nom, matricule;
	protected double indiceSalaire;
	protected double salaire;
	
	
	

	
	public Employee(String nom, String matricule, double indiceSalaire, double salaire) {
		super();
		this.nom = nom;
		this.matricule = matricule;
		this.indiceSalaire = indiceSalaire;
		this.salaire = salaire;
	}

	public double calculerSalaire() {
		
		return indiceSalaire*this.salaire;
		
	}

	@Override
	public String toString() {
		return "Employee [nom=" + nom + ", matricule=" + matricule + ", indiceSalaire=" + indiceSalaire + ", salaire="
				+ this.calculerSalaire()+ "]";
	}
	
	
	
	
	
	
	
	

}
