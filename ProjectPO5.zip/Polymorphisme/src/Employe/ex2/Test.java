package Employe.ex2;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		
		Employee emp1 = new Employee("Fronton Froncois", "FFCVB1234", 1.25, 50000); 
		Employee emp2 = new Employee("Franklein Jean", "FFJCVB6666", 1.5, 65000); 
		Employee emp3 = new Employee("Blanche Nathalie", "BNNB1234", 1.75, 70000); 
		
		ArrayList<Employee> emps = new 	ArrayList<Employee> ();
		emps.add(emp3);
		emps.add(emp2);
		emps.add(emp1);

		
		System.out.println(emp1);
		System.out.println(emp2);
		System.out.println(emp3);
		
		
		Responsable rep = new Responsable ("Frank lamez", "FL696698", 90000, 2.25, emps); 
		
		System.out.println(rep);
		
		
		Commercial com1 = new Commercial("Lacroix Catherine", "LC124457", 1.25, 10200, 0.01, 50000);
		
		System.out.println(com1);
	}

}
