package heritage1;

public class Rectangle {

protected double longueur, largeur;


public Rectangle() {

	// TODO Auto-generated constructor stub
}

public Rectangle(double longueur, double largeur) {

	this.longueur = longueur;
	this.largeur = largeur;
}





public Rectangle (double seul) {
	
	this(seul, seul);
	
}

public double perimetre() {
	
	return 2 * (this.largeur + this.longueur);
	
}

public double surface() {
	
	return this.longueur * this.largeur;
	
}

@Override
public String toString() {
	return "Rectangle [longueur=" + longueur + ", largeur=" + largeur + "]";
}







}
