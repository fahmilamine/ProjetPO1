package heritage1;

public class Caree extends Rectangle {

public Caree(double cote) {
	
	super(cote);
	
	
}


public double diagonale() {
	
	
	return Math.sqrt(2.0)+largeur;
}


@Override
public String toString() {
	return "Caree [+"+ super.toString() + "]";
}





	 
}



