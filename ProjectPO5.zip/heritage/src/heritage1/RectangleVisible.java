package heritage1;

public class RectangleVisible extends Rectangle {
	
	
private boolean isVisible;


public RectangleVisible(double longueur, double largeur, boolean isVisible) {
	super(longueur, largeur);
	this.isVisible = isVisible;
}


@Override
public String toString() {
	return "RectangleVisible [isVisible=" + isVisible + ", "+ super.toString() + "]";
}






}
