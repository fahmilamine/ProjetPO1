package heritage2;

public class Vehicule {
	
	
	protected double vitesse;
	protected int nbre_passagers;
	
	
	public Vehicule() {
		this.vitesse = 0;
		this.nbre_passagers = 0;
	}
	
	
	public Vehicule(double vitesse, int nbre_passagers) {
		this.vitesse = vitesse;
		this.nbre_passagers = nbre_passagers;
	}
	
	public void affiche() {
		
		System.out.println("Vitesse : " + vitesse +" ,  Nb-Passager : " + nbre_passagers   );
	}
	
	
	
	

}
