package heritage2;

public class TestVehicule {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	
	Vehicule v1  = new Vehicule();
	Vehicule v2  = new Vehicule(200, 5);
	
	Avion av1 =  new Avion(355, 7, 6,2);
	
	
    v1.affiche();
	v2.affiche();
	
	av1.affiche();;
	
	
	
	}

}
