package hertitage3;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


	Person p1 = new Person();
	p1.sayHello();
	
	Student s1 = new Student(15);
	s1.sayHello();
	s1.goToClasses();
	s1.DisplayAge();
	
	
	Teacher t1 = new Teacher(40);
	t1.sayHello();
	t1.explain();

	
	
	
	
	
	}

}
