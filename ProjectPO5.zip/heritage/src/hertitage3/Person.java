package hertitage3;

public class Person {


protected int age;

public Person(int age) {
	super();
	this.age = age;
}

public Person() {
	super();
	// TODO Auto-generated constructor stub
}


public void sayHello() {
	
	System.out.println("Hello");

	
}

public void setAge(int n) {
	
	this.age = n;
}

@Override
public String toString() {
	return "Person [age=" + age + "]";
}






}
