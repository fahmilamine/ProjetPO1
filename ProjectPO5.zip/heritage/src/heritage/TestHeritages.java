package heritage;


public class TestHeritages {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	CompteSimple c11 = new CompteSimple(5000);
	System.out.println(c11);
	
	CompteSimple c22 = new CompteSimple(3000, 500);
	System.out.println(c22);
	
	
	CompteSimple c33 = new CompteSimple();
	System.out.println(c33);
	
	//Compte.nbCompte;
	
	
	
	
	}

}
