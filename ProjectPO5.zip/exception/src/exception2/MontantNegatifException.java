package exception2;

public class MontantNegatifException extends Exception {
	
	public MontantNegatifException (String message) {
		
		super(message);
		
	}


}
