package exception2;



	import java.util.InputMismatchException;
import java.util.Scanner;

	public class App2 {
	public static void main(String[] args) {
		
		Compte cp = new Compte();
		
		try {
			
			
			Scanner clavier=new Scanner(System.in);
			System.out.print("Montant � verser:");
			float mt1=clavier.nextFloat();
			cp.verser(mt1);
			System.out.println("Solde Actuel:"+cp.getSolde());
			System.out.print("Montant � retirer:");
			float mt2=clavier.nextFloat();
			cp.retirer(mt2);
			}
			catch (SoldeInsuffisantException e) {
			System.out.println(e.getMessage());
			}
			catch (InputMismatchException e) {
			System.out.println("Probl�me de saisie");
			}
			catch (MontantNegatifException e) {
			System.out.println(e.getMessage());
			}
			System.out.println("Solde Final="+cp.getSolde());
	}
	}
	



