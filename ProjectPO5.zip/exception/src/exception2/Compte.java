package exception2;

public class Compte {
	

	private int code;
	private float solde;
	public void verser(float mt){
	solde=solde+mt;
	}
	public void retirer(float mt) throws SoldeInsuffisantException, MontantNegatifException  {
	if(mt>solde) throw new SoldeInsuffisantException("Solde Insuffisant");
	
	if(mt<0) throw new MontantNegatifException("Montant n�gatif");
	
	

	solde=solde-mt;
	}
	public float getSolde(){
	return solde;
	}
	}


