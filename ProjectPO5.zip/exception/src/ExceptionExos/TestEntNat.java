package ExceptionExos;

public class TestEntNat {

	public static void main(String[] args){
	
	
			try {
				EntNat e1 = new EntNat(-1);
			} catch (ErrConst e) {
				
				//System.out.println(e.getMessage());
			}
		

	}

}
