package ExceptionExos;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exo1Q1 {
	
	
	/*static void saisieCorrect(){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Donnez un entier : ");
		int nombre = sc.nextInt();
		System.out.println("L'entier saisi est : " + nombre);
		sc.close();
		
		
	}

	public static void main(String[] args) {
		
		while(true) {
			
			
		try {
		saisieCorrect();
		break;
		
		}catch(InputMismatchException e){
			
			System.out.println("Erreur de saisie !!");
		}finally {
			
			
			System.out.println("Fin");
		}
		
		}
	}
*/
}
