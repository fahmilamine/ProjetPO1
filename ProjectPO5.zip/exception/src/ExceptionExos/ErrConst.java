package ExceptionExos;

public class ErrConst extends Exception{

	public ErrConst() {
		//super("alllllo ici  test ");
		
		System.out.println("Aloooooooo ici Test");
		
		
	}
	
	
	

}
