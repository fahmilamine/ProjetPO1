package ExceptionExos;

public class EntNat{
	
	private int n;

	public EntNat(int n) throws ErrConst {
	    
		if(n<0) throw new ErrConst();
		this.n = n;
	}

	
	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
	}
	
	
	
	
	

}
