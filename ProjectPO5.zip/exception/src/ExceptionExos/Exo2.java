package ExceptionExos;

import java.util.Scanner;

public class Exo2 {
	
	static int fibo(int nombre) throws FiboException {
		
		if(nombre<0) throw new FiboException("Donner une valeur sup�rieur � 0");
		
		if(nombre == 0 || nombre == 1) 
			return nombre;
		else
			return fibo(nombre-2)+fibo(nombre-1);
		
	}
	

	public static void main(String[] args) {
		
        while(true) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Donnez un entier : ");
		int nombre = sc.nextInt();
		
		try {
		System.out.println("Resultat Fibo : " +fibo(nombre));
		break;
		
		}catch(FiboException e) {
			
			System.out.println(e.getMessage());
		}
		
        }

	}

}
