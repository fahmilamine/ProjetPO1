package exception3;

public class Div8 {

		public static int divint (int x, int y) { return (x/y);
		}
		static void main (String [] args) { 
			
			int c=0,a=1,b=0;
		try {
		c= divint(a,b);
		}
		catch (ArithmeticException e) { 
			
			System.out.println("Erreur a �t� captur�e");
		
		}
		finally {
		System.out.println("on est arriv� � la fin du cours!");
		}
		System.out.println("res: " + c); 
		System.exit(0);
		}
		
}
