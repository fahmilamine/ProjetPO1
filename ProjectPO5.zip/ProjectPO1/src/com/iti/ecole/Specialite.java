package com.iti.ecole;

import java.util.Objects;

public class Specialite {

private int id;
private String code, libelle;
static int compteur = 0;






public Specialite() {
this.id = ++compteur;	
}






public Specialite(String code, String libelle) {
	super();
	this.id = ++compteur;
	this.code = code;
	this.libelle = libelle;
}






public int getId() {
	return id;
}






public void setId(int id) {
	this.id = id;
}






public String getCode() {
	return code;
}






public void setCode(String code) {
	this.code = code;
}






public String getLibelle() {
	return libelle;
}






public void setLibelle(String libelle) {
	this.libelle = libelle;
}






@Override
public String toString() {
	return "Specialite [id=" + id + ", code=" + code + ", libelle=" + libelle + "]";
}






@Override
public int hashCode() {
	return Objects.hash(code, id, libelle);
}






@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Specialite other = (Specialite) obj;
	return Objects.equals(code, other.code) && id == other.id && Objects.equals(libelle, other.libelle);
}








}

