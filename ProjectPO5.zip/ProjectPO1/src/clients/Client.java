package clients;

public class Client {

private String CIN, nom, prenom, tel;

public Client() {
	super();
	// TODO Auto-generated constructor stub
}

public Client(String cIN, String nom, String prenom, String tel) {
	super();
	CIN = cIN;
	this.nom = nom;
	this.prenom = prenom;
	this.tel = tel;
}


public Client(String cIN, String nom, String prenom) {
	super();
	CIN = cIN;
	this.nom = nom;
	this.prenom = prenom;
}

// Getters et setters
public String getCIN() {
	return CIN;
}

public void setCIN(String cIN) {
	CIN = cIN;
}

public String getNom() {
	return nom;
}

public void setNom(String nom) {
	this.nom = nom;
}

public String getPrenom() {
	return prenom;
}

public void setPrenom(String prenom) {
	this.prenom = prenom;
}

public String getTel() {
	return tel;
}

public void setTel(String tel) {
	this.tel = tel;
}


public String afficher() {
	return "[CIN=" + CIN + ", nom=" + nom + ", prenom=" + prenom + ", tel=" + tel + "]";
}

// Function d'affichage







}
