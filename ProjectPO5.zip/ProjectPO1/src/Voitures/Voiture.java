package Voitures;

import java.util.Date;

public class Voiture {

private int id, puissance, vitesse;
private String marque;
static int compteur = 0;

Date x;


public Voiture() {
	super();
	// TODO Auto-generated constructor stub
}


public Voiture(int puissance, int vitesse, String marque) {
	super();
	this.id = ++compteur;
	this.puissance = puissance;
	this.vitesse = vitesse;
	this.marque = marque;
}


public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


public int getPuissance() {
	return puissance;
}


public void setPuissance(int puissance) {
	this.puissance = puissance;
}


public int getVitesse() {
	return vitesse;
}


public void setVitesse(int vitesse) {
	this.vitesse = vitesse;
}


public String getMarque() {
	return marque;
}


public void setMarque(String marque) {
	this.marque = marque;
}


@Override
public String toString() {
	return "Voiture [id=" + id + ", puissance=" + puissance + ", vitesse=" + vitesse + ", marque=" + marque + "]";
}










}
