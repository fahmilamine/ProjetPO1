package Personnes;

public class Personne {
	
	protected int id;
	protected String nom;
	protected String prenom;
	protected String mail;
	protected String telephone;
	protected double salaire;
	
	private static int cmp = 0;

public Personne() {
		
		this.id = ++cmp;
		this.nom = "X";
		this.prenom = "X";
		this.mail = "X";
		this.telephone = "X";
		this.salaire = 0.0;
	
	}

	public Personne(String nom, String prenom, String mail, String telephone, double salaire) {
		
		this.id = ++cmp;
		this.nom = nom;
		this.prenom = prenom;
		this.mail = mail;
		this.telephone = telephone;
		this.salaire = salaire;
	}
	
	public double calculerSalaire() {
		
		return this.salaire;
	}
	
	public void afficher() {
		
		System.out.println("Personne [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", mail=" + mail + ", telephone="
				+ telephone + ", salaire=" + salaire + "]");
		
	}

}
	
	
	

