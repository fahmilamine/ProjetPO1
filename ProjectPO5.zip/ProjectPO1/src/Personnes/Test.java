package Personnes;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		
		/*
		o	Chef de projet (CP),
		o	Manager (MN),
		o	Directeur de projet (DP),
		o	Directeur des ressources humaines (DRH),
		o	Directeur g�n�ral (DG),
		
		*/
		
		ArrayList<Profil> profils = new ArrayList<Profil>();
		profils.add(new Profil("CP", "Chef de projet"));
		profils.add(new Profil("MN", "Manager"));
		profils.add(new Profil("DP", "Directeur de projet"));
		profils.add(new Profil("DRH", "Directeur des ressources humaines"));
		profils.add(new Profil("DG", "Directeur g�n�ral"));
		
		ArrayList<Utilisateur> utilisateurs = new ArrayList<Utilisateur>();
		utilisateurs.add(new Utilisateur("Bergeron", "Alex1", "alex1@gmail.com", "514-956-6969", 65000, "balex1",
				"124587Xcvb", "IT", profils.get(0)));
		utilisateurs.add(new Utilisateur("Bergeron", "Alex2", "alex2@gmail.com", "514-956-0000", 95000, "balex2",
				"124587Xcvb", "IT", profils.get(1)));
		utilisateurs.add(new Utilisateur("Bergeron", "Alex3", "alex3@gmail.com", "514-956-6154", 75000, "balex3",
				"124587Xcvb", "IT", profils.get(2)));
		utilisateurs.add(new Utilisateur("Bergeron", "Alex4", "alex4@gmail.com", "514-956-6962", 80000, "balex4",
				"124587Xcvb", "IT", profils.get(3)));
		utilisateurs.add(new Utilisateur("Bergeron", "Alex5", "alex5@gmail.com", "514-956-6978", 90000, "balex5",
				"124587Xcvb", "IT", profils.get(4)));
		
		utilisateurs.add(new Utilisateur("Bergeron", "Alex6", "alex6@gmail.com", "514-956-6978", 90000, "balex5",
				"124587Xcvb", "IT", profils.get(1)));
		
		System.out.println("*******************************************");
		
		System.out.println(" La liste des utilisateurs");
		
		System.out.println("*******************************************");
		
		for(Utilisateur user : utilisateurs) {
			
			user.afficher();
			
			
		}
		
       System.out.println("*******************************************");
		
		System.out.println(" La liste des managers");
		
		System.out.println("*******************************************");
		
		
	for(Utilisateur user : utilisateurs) {
			
		if(user.getProfil().getCode().equalsIgnoreCase("MN"))	
		user.afficher();
			
			
		}
		

	}

}
