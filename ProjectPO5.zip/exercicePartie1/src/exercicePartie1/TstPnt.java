package exercicePartie1;

public class TstPnt { 
public static void main (String args[]) { 
Point a ; 

a = new Point(3, 5) ;
 System.out.println("Je suis un point de coordonnees " + a.abscisse() + " " + a.ordonne());

//a.affiche() ;
 a.deplace(2, 0) ; 
//a.affiche() ; 
 
 System.out.println("Je suis un point de coordonnees " + a.abscisse() + " " + a.ordonne());
Point b = new Point(6, 8) ; 
//b.affiche() ; 

System.out.println("Je suis un point de coordonnees " + b.abscisse() + " " + b.ordonne());
} 
}
