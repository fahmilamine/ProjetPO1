package exercicePartie1;

class Point { 
public Point (int abs, int ord) {
 x = abs ; 
y = ord ; 
} 
public void deplace (int dx, int dy) { 
x += dx ; 
y += dy ; 
} 
/*public void affiche () { 
System.out.println ("Je suis un point de coordonnees " + x + " " + y) ; 
}*/ 



public double abscisse(){
	
	return x;
} 

public double ordonne(){
	
	return y;
}

private double x ; // abscisse 
private double y ; // ordonnee 
} 

