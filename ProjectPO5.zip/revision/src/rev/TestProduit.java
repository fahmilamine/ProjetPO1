package rev;

public class TestProduit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Produit p1 = new Produit();
		System.out.println(p1);
		
	// id =1, nom="PS5", prix=999, description="Console de jeux", poids= 2
		
		Categorie cat = new Categorie(1,"Console");
		
		p1.setId(1);
		p1.setNom("PS5");
		p1.setPrix(999);
		p1.setDescription("Console de jeux SONY");
		p1.setPoids(2);
		p1.setNom("PS6");
		p1.setCat(cat);
		
		System.out.println(p1);
		
		
		
		
		Produit p2 = new Produit(2,"XBOX360", 899.99, "Console de jeux Microsoft", 2.4, cat);
		System.out.println(p2);
		
		
		
	
	}

}

