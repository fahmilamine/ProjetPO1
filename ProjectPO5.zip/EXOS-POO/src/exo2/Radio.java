package exo2;

public class Radio implements Electrique {

	public void allumer() {
		System.out.println("Tu es ON !!!!");
		
	}

	public void eteindre() {
		System.out.println("Tu es OFF !!!!");
		
	}

}
