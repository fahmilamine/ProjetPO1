package exo2;

public class Test {

	public static void main(String[] args) {
		
		Radio x1 = new Radio();
		
		x1.allumer();
		x1.eteindre();

	}

}
