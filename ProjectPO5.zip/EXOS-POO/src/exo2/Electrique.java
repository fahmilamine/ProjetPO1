package exo2;

public interface Electrique {
	
	void allumer();
	void eteindre();

}
