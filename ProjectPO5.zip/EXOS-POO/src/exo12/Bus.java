package exo12;

public class Bus extends Vehicule {
	

	private int nbVoyageur;
	private int maxVoyageur;
	
	
	public Bus(String matricule, String marque, double vitesse, boolean etat, int nbVoyageur, int maxVoyageur) {
		super(matricule, marque, vitesse, etat);
		this.nbVoyageur = nbVoyageur;
		this.maxVoyageur = maxVoyageur;
	}


	public int getNbVoyageur() {
		return nbVoyageur;
	}


	public void setNbVoyageur(int nbVoyageur) {
		this.nbVoyageur = nbVoyageur;
	}


	public int getMaxVoyageur() {
		return maxVoyageur;
	}


	public void setMaxVoyageur(int maxVoyageur) {
		this.maxVoyageur = maxVoyageur;
	}
	
	
	public void monter(int nombre) {
		
		int nb;
		nb= this.nbVoyageur +nombre;
		
		if(nb<=this.maxVoyageur)
			this.nbVoyageur = nb;
		else
			System.out.println("D�sol� le nombre de voyageur excede la capacit� autoris�e !!!!");
		
	}
	
	public void descendre(int nombre) {
		
		int nb;
		nb = this.nbVoyageur - nombre;
		
		if(nb>=0)
			this.nbVoyageur = nb;
		else
			System.out.println("Le nombre de voyageur donn�e d�passe le nombre des voyageurs pr�sent dans le bus!!!!");
		
	}


	@Override
	public String toString() {
		return "Bus [nbVoyageur=" + nbVoyageur + ", maxVoyageur=" + maxVoyageur + ", matricule=" + matricule
				+ ", marque=" + marque + ", vitesse=" + vitesse + ", etat=" + etat + "]";
	}
	
	
	
	
	
	
	
	
	

}
