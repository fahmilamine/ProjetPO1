package exo12;

public class Vehicule {
	
   protected String matricule;
   protected String marque;
   protected double vitesse;
   protected boolean etat;

   
   public Vehicule() {
	super();
	// TODO Auto-generated constructor stub
}


    public Vehicule(String matricule, String marque, double vitesse, boolean etat) {
		super();
		this.matricule = matricule;
		this.marque = marque;
		this.vitesse = vitesse;
		this.etat = etat;
	}
   
   
   public void accelerer() {
	   
	   this.vitesse = this.vitesse + 5;
   }
   
   
 public void freiner() {
	  
	 if(this.vitesse>=5)
	   this.vitesse = this.vitesse - 5;
	 else
	   this.vitesse = 0;	 
   }
 
 
 public void demarrer() {
	 this.etat = true;
 }
 
 public void arreter() {
	 this.etat = false ;
	 this.vitesse = 0;
 }


@Override
public String toString() {
	return "Vehicule [matricule=" + matricule + ", marque=" + marque + ", vitesse=" + vitesse + ", etat=" + etat + "]";
}
 
 
 
   

}
