package exo12;

public class TestVehicule {

	public static void main(String[] args) {
		
		Vehicule v1 = new Vehicule("ALPH123", "BMW" , 155, true);
		
		Vehicule v2 = new Vehicule("XCKL56", "AUDI" , 0, false);
		
		System.out.println("--------------------------");
		
		System.out.println(v1);
		System.out.println();
		System.out.println(v2);
		
		System.out.println("--------------------------");
		v1.freiner();
		v2.accelerer();
		System.out.println(v1);
		System.out.println();
		System.out.println(v2);
		
		System.out.println("--------------------------");
		
		v1.arreter();;
		v2.arreter();;
		System.out.println(v1);
		System.out.println();
		System.out.println(v2);
		
		System.out.println("--------------------------");
		
		Camion c1 = new Camion ("XXCV12", "MERCEDES", 100, true, 1000,850);
		System.out.println(c1);
		System.out.println("--------------------------");
		c1.charger(200);
		c1.decharger(600);
		System.out.println(c1);
		System.out.println("--------------------------");
		
		
		Bus b1 = new Bus("XCB235", "KIA", 60, true, 20, 80);
		System.out.println(b1);
		System.out.println("--------------------------");
		
		b1.monter(50);
		b1.descendre(200);
		System.out.println(b1);
	
		
		
		
		
		

	}

}
