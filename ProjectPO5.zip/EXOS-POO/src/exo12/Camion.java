package exo12;

public class Camion extends Vehicule {
	
	
	private double chargeMax;
	private double poidsChargement;
	
	
	public Camion(String matricule, String marque, double vitesse, boolean etat, double chargeMax,
			double poidsChargement) {
		super(matricule, marque, vitesse, etat);
		
		
		if(this.poidsChargement> this.chargeMax) {
			
			System.out.println(" Votre chargement d�passe le poids autoris� !!!! ");
		}else {
			
			this.chargeMax = chargeMax;
			this.poidsChargement = poidsChargement;
			
		}
		
	}


	public double getChargeMax() {
		return chargeMax;
	}


	public void setChargeMax(double chargeMax) {
		this.chargeMax = chargeMax;
	}


	public double getPoidsChargement() {
		return poidsChargement;
	}


	public void setPoidsChargement(double poidsChargement) {
		this.poidsChargement = poidsChargement;
	}


	@Override
	public String toString() {
		return "Camion [chargeMax=" + chargeMax + ", poidsChargement=" + poidsChargement + ", matricule=" + matricule
				+ ", marque=" + marque + ", vitesse=" + vitesse + ", etat=" + etat + "]";
	}
	
	
	public void charger(double charge) {
		
		double poids;
		
		poids = this.poidsChargement + charge;
		
		if(poids <= this.chargeMax)
			this.poidsChargement = poids;
		else
			System.out.println(" Votre chargement d�passe le poids autoris� !!!! ");
			
		
	}
	
	
	public void decharger(double charge) {
		
		double poids = 0;
		
		if(charge<=this.poidsChargement)
		poids = this.poidsChargement-charge;
		
		if(poids >= 0)
			this.poidsChargement =poids;
	}
	
	
	
	
	
	
	
	

}
