package exo11;

public class BoissonAlcoolisee extends Boisson {
	
	private double degreAlcool;

	public BoissonAlcoolisee(String nom, double prix, double degreAlcool) {
		super(nom, prix);
		this.degreAlcool = degreAlcool;
	}
	
	
	public void afficher() {
		super.afficher();
		System.out.println("Degr� d'alcool :" +degreAlcool);
	}

	@Override
	public String toString() {
		return "BoissonAlcoolisee [degreAlcool=" + degreAlcool + ", nom=" + nom + ", prix=" + prix + "]";
	}
	
	

}
