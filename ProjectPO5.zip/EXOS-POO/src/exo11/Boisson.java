package exo11;

public class Boisson {
	
	protected String nom;
	protected double prix;
	
	
	public Boisson() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Boisson(String nom, double prix) {
		super();
		this.nom = nom;
		this.prix = prix;
	}
	
	public void afficher() {
		System.out.println(" Infos dur la boisson ");
		System.out.println(" Nom de la boisson : " +nom);
		System.out.println(" Prix de la boisson : " +prix);	
	}


	@Override
	public String toString() {
		return "Boisson [nom=" + nom + ", prix=" + prix + "]";
	}
	
	
	
	
	
	
	
	

}
