package exo11;

public class TestBoisson {

	public static void main(String[] args) {
	
		
		Boisson b1 = new Boisson("PEPSI", 1.89);
		
		
		BoissonAlcoolisee b2 = new BoissonAlcoolisee("REDONE", 21.5, 0.9);
		
		
		b1.afficher();
		b2.afficher();

	}

}
