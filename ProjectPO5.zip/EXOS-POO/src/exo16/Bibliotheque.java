package exo16;

public class Bibliotheque {

	public static void main(String[] args) {
		
		Livre livre1 = new Livre("JAVA2022", "MIKE", 600);
		
		Livre livre2 = new Livre("REACT");
		
		System.out.println(livre1);
		System.out.println(livre2);

	}

}
