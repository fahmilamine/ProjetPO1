package exo1;

public  abstract class Serieux {
	
	void afficher() {
		
		System.out.println("Je suis une personne serieuse");
	}
	
	abstract void devoir();
	
}
