package exo1;

public class Etudiant extends Serieux {

	@Override
	void devoir() {
		System.out.println("Je dois r�viser mon cours");
		
	}

}
