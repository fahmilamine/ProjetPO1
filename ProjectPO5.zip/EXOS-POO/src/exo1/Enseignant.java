package exo1;

public class Enseignant extends Serieux {

	@Override
	void devoir() {
		 System.out.println("Je dois donner un bon cours");
		
	}

}
