package exo1;

public class Test {

	public static void main(String[] args) {
	
		
		 Serieux x1 =  new Enseignant();
		 
		 Serieux x2 =  new Etudiant();
		 
		 
		 x1.afficher();
		 x2.afficher();
		 
		 x1.devoir();
		 x2.devoir();

	}

}
