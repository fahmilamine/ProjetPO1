package exo15;

public class TestMonEntier {

	public static void main(String[] args) {
		
		
		MonEntier x = new MonEntier(4);
		
		System.out.println(x.ajouter(new MonEntier(10)).valeur);
		System.out.println(x.diminuer(new MonEntier(5)).valeur);
		System.out.println(x.multiplier(new MonEntier(2)).valeur);
		System.out.println(x.divEntier(new MonEntier(5)).valeur);
		System.out.println(x.puisse(new MonEntier(0)).valeur);
		System.out.println(x.factoriel().valeur);

	}

}
