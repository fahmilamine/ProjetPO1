package exo15;

public class MonEntier {
	
	int valeur;

	public MonEntier(int valeur) {
		super();
		this.valeur = valeur;
		
	}
	
	public MonEntier ajouter(MonEntier n) {
		
		MonEntier som = new MonEntier(0);
		
		som.valeur = this.valeur + n.valeur; 
		
		return som;
	}
	
	
	public MonEntier diminuer(MonEntier n) {
		
		MonEntier diff = new MonEntier(0);
		
		diff.valeur = this.valeur - n.valeur; 
		
		return diff;
	}
	
public MonEntier multiplier(MonEntier n) {
		
		MonEntier mult = new MonEntier(0);
		
		mult.valeur = this.valeur * n.valeur; 
		
		return mult;
	}


public MonEntier divEntier(MonEntier n) {
	
	MonEntier div = new MonEntier(0);
	
	div.valeur = this.valeur / n.valeur; 
	
	return div;
}


public MonEntier puisse(MonEntier n) {
	
	MonEntier resultat = new MonEntier(0);
	
	resultat.valeur = (int) Math.pow(this.valeur,  n.valeur); 
	
	return resultat;
}


public MonEntier factoriel() {
	
	MonEntier resultat = new MonEntier(1);
	
	for(int i =1; i<=this.valeur; i++) {
		
		resultat.valeur *= i;
	}
	
	
	
	return resultat;
}


public void afficher() {
	
	System.out.println("La valeur de l'entier = "+this.valeur);
	
}
	
	

}
