package exo3;

public class Hello implements Salut{


	public void saluer() {
		System.out.println("HELLO!!!!");
		
	}

}
