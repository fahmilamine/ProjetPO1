package exo3;

public class Test {

	public static void main(String[] args) {
	
		
		Salut s1 = new Salam();
		Salut s2 = new Hello();
		
		
		s1.saluer();
		s2.saluer();

	}

}
