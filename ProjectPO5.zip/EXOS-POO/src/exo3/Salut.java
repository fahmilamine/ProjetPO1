package exo3;

public interface Salut {
	
	public void saluer();

}
