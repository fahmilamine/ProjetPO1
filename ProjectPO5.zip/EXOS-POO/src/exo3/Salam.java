package exo3;

public class Salam implements Salut {

	@Override
	public void saluer() {
	     System.out.println("SALAM !!!!!");
		
	}

}
