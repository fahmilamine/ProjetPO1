package exo4;

public interface X {
	
	int actionone();
	int actiontwo();
	int actionthree();

}
