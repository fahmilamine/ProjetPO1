package exo5;

public class Test {

	public static void main(String[] args) {

		
		int i = 2;
		double d = 4.5;

		Addition x1  = new Addition();
		System.out.println(x1.additionner(i, i));
		System.out.println(x1.additionner(d, d));
		
		
	

	}

}
