package exo5;

public class Addition {
	
	private int a , b;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public Addition(int a, int b) {
		super();
		this.a = a;
		this.b = b;
	}
	
	
	public Addition() {
		
	}
	public int additionner(int a , int b) {
		System.out.println("Ceci est un entier");
		return a+b;
			
	}
	
	public double additionner(double a , double b) {
		System.out.println("Ceci est un r�el");
		return a+b;
			
	}
	
	

}
