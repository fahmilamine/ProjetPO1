package exo14;

public class TestPoint {

	public static void main(String[] args) {

     Point p  = new Point('A', 10,5);
     
     p.afficher();
     p.deplacer(12, 20);
     p.afficher();
     p.distance(new Point('B', 12,12));

	}

}
