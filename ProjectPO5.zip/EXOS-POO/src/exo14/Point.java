package exo14;

public class Point {
	
	private char nom;
	private double x, y;
	
	
	public Point(char nom, double x, double y) {
		super();
		this.nom = nom;
		this.x = x;
		this.y = y;
	}


	public char getNom() {
		return nom;
	}


	public void setNom(char nom) {
		this.nom = nom;
	}


	public double getX() {
		return x;
	}


	public void setX(double x) {
		this.x = x;
	}


	public double getY() {
		return y;
	}


	public void setY(double y) {
		this.y = y;
	}
	
	
	public void afficher() {
		
		System.out.println(" Les coordonn�es du point " +nom + " sont : \n" + " X: " +x +"\n" + "Y : " +y);
		
	}
	
	
	public void deplacer(double dx, double dy) {
		
		this.x += dx;
		this.y+=dy;
		
	}
	
	public void distance(Point p) {
		
		System.out.println("La distance entre les deux points : " + Math.sqrt(this.x-p.x) * (this.x-p.x) + (this.y-p.y)*(this.y-p.y));
		
	}
	
	
	
	

}
