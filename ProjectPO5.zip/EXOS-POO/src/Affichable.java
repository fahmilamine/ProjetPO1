
public interface Affichable {
	
	

}
