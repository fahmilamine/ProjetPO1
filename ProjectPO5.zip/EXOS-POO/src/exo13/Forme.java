package exo13;

public abstract class Forme implements Affichable, Calculable {
	
	
	protected double x, y;
	protected String couleur;
	

	public Forme(double x, double y, String couleur) {
		super();
		this.x = x;
		this.y = y;
		this.couleur = couleur;
	}

	@Override
	public void calculSurface() {
		System.out.println("Pour la surface j'ai besoin du type de la forme");
		
	}

	@Override
	public void calculPerimetre() {
		System.out.println("Pour le perimetre j'ai besoin du type de la forme");
		
	}

	@Override
	public void deplacer(int x, int y) {
		this.x = this.x + x;
		this.y = this.y + y;
		
	}

	@Override
	public void colorer(String couleur) {
		this.couleur = couleur;
		
	}

	
	public void afficher() {
		System.out.println( "Forme [x=" + x + ", y=" + y + ", couleur=" + couleur + "]");
	}
	
	

}
