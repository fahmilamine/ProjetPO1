package exo13;

public class Cercle extends Forme {
	
	private double rayon;

	public Cercle(double x, double y, String couleur, double rayon) {
		super(x, y, couleur);
		this.rayon = rayon;
	}
	
	
	@Override
	public void calculSurface() {
		System.out.println("Surface : " + Math.PI * Math.pow(rayon, 2));
		
	}

	@Override
	public void calculPerimetre() {
		System.out.println("Perimetre : " +2*Math.PI* rayon);
		
	}
	
	public void afficher() {
		System.out.println( "Cercle [rayon=" + rayon + ", x=" + x + ", y=" + y + ", couleur=" + couleur + "]");
	}


	
	

	

}
