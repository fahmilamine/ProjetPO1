package exo13;

public class TestForme {

	public static void main(String[] args) {
		
		
		
		
		
		Rectangle r = new Rectangle(0,10, "Jaune", 122,155);
		
		r.afficher();
		
		Cercle c = new Cercle(5,15, "Rose", 6);
		
		c.afficher();

	}

}
