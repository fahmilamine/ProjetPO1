package exo13;

public class Rectangle extends Forme {
	
	private double longueur, largeur;

	
	
	public Rectangle(double x, double y, String couleur, double longueur, double largeur) {
		super(x, y, couleur);
		this.longueur = longueur;
		this.largeur = largeur;
	}

	@Override
	public void calculSurface() {
		System.out.println("Surface : " +this.largeur * this.longueur);
		
	}

	@Override
	public void calculPerimetre() {
		System.out.println("Perimetre : " +(this.largeur +this.longueur) * 2);
		
	}
	
	public void afficher() {
		System.out.println( "Rectangle [longueur=" + longueur + ", largeur=" + largeur + ", x=" + x + ", y=" + y + ", couleur="
				+ couleur + "]");
	}

	
	
	
	
	


}
