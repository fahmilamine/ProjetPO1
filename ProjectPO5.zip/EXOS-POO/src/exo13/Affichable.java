package exo13;

public interface Affichable {
	
public void deplacer(int x, int y);
public void colorer(String couleur);

}
