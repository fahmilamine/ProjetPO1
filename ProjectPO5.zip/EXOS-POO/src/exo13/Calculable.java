package exo13;

public interface Calculable {
	
	public void calculSurface();
	public void calculPerimetre();

}
