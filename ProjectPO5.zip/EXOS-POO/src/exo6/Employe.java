package exo6;

public abstract class Employe {
	
	protected String nom;

	public Employe(String nom) {
		super();
		this.nom = nom;
	}
	
	public String getNom() {
		return this.nom;
		
	}
	
	public abstract void show();
	
	

}
