package exo6;

public class Manager extends Employe {

	public Manager(String nom) {
		super(nom);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void show() {
		System.out.println(" Nom du Manager :  "+ this.getNom());
		
	}

}
