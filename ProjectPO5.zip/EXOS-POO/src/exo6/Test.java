package exo6;

public class Test {

	public static void main(String[] args) {
		Manager m = new Manager("BOB");
		m.show();

	}

}
