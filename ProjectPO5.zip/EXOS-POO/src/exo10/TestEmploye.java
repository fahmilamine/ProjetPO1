package exo10;

public class TestEmploye {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employe emp1 = new Employe("Jean", 85000);
		
		
		Chef emp2 = new Chef("JANEX", 95000, 5000);
		
		
		emp1.afficher();
		System.out.println(emp2);

	}

}
