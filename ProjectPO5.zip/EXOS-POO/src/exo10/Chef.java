package exo10;

public class Chef extends Employe{
	
	private double prime;

	public Chef(String nom, double salaire, double prime) {
		super(nom, salaire);
		this.prime = prime;
	}

	public double getPrime() {
		return prime;
	}

	public void setPrime(double prime) {
		this.prime = prime;
	}

	@Override
	public String toString() {
		return "Chef [Nom=" + getNom() + ", Salaire=" + getSalaire() + "," +"Prime=" + prime +"]";
				
	}
	
	
	

}
