package exo10;

public class Employe {
	
	private String nom;
	private double salaire;
	
	
	public Employe(String nom, double salaire) {
		super();
		this.nom = nom;
		this.salaire = salaire;
	}


	public Employe() {
		super();
		// TODO Auto-generated constructor stub
	}


	
	// Getters et setters
	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public double getSalaire() {
		return salaire;
	}


	public void setSalaire(double salaire) {
		this.salaire = salaire;
	}
	
	public void afficher() {
		System.out.println("nom : " + this.nom + "  et son salaire : " + this.salaire);
	}
	



	@Override
	public String toString() {
		return "Employe [nom=" + nom + ", salaire=" + salaire + "]";
	}
	
	
	
	

	
	
	
	
	
	
	
	
	
	

}
