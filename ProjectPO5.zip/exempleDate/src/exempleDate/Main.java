package exempleDate;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
   /* Period twoMonthsAndFiveDays = Period.ofMonths(2).plusDays(5);
    LocalDate sixthOfJanuary = LocalDate.of(2014, 1, 6);

    LocalDate eleventhOfMarch = sixthOfJanuary.plus(twoMonthsAndFiveDays);

    
    System.out.println(twoMonthsAndFiveDays);
    System.out.println(eleventhOfMarch);*/
		 Scanner input = new Scanner(System.in);
	     String cinput = input.nextLine();
	    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("M/d/yyyy");
	    LocalDate date = LocalDate.parse(cinput, dateFormat);


	    System.out.println(date);
	  
	  
  }
}