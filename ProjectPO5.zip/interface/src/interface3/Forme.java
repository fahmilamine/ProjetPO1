package interface3;

public class Forme implements CalculGeometrique {
	
	protected double x, y;

	@Override
	public double surface() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double perimetre() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String toString() {
		return "Forme [x=" + x + ", y=" + y + "]";
	}
	
	
	

}
