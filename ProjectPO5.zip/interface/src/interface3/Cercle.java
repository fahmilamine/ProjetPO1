package interface3;

public class Cercle extends Forme{
	
	private double r;

	public Cercle(double r) {
		super();
		this.r = r;
	}

	public double getR() {
		return r;
	}

	public void setR(double r) {
		this.r = r;
	}

	@Override
	public String toString() {
		return "Cercle [r=" + r + "]";
	}

/*	@Override
	public double surface() {
		return Math.PI*r*r;
	}
	
	*/

	@Override
	public double perimetre() {
	   return 2*r*Math.PI;
	}
	
	
	
	
	
	
	
	
	

}
