package interface3;

public interface CalculGeometrique {
	
	public double surface();
	public double perimetre();

}
