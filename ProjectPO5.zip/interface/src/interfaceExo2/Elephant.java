package interfaceExo2;

public class Elephant implements Animal {

	private int poids;

	
	public int getNbLegs() {
		// TODO Auto-generated method stub
		return 4;
	}

	public boolean isCarvnivorous() {
		return false;
	}
	

	public Elephant(int poids) {
		super();
		this.poids = poids;
	}

	public int getPoids() {
		return poids;
	}

	public void setPoids(int poids) {
		this.poids = poids;
	}

	@Override
	public String toString() {
		return "Elephant [poids=" + poids + ", getNbLegs()=" + getNbLegs() + ", isCarvnivorous()=" + isCarvnivorous()
				+ "]";
	}

	
	
	
}
