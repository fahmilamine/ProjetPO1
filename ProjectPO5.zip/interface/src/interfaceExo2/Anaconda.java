package interfaceExo2;

public class Anaconda implements Animal {

	public int getNbLegs() {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean isCarvnivorous() {
		return true;
	}
	

	public Anaconda() {
		
	}

	@Override
	public String toString() {
		return "Anaconda [getNbLegs()=" + getNbLegs() + ", isCarvnivorous()=" + isCarvnivorous() + "]";
	}
	
	
	

	
	
}
