package interfaceExo2;

public class Zoo {
	
	
	public void addAnimal(Animal animal) {
		
		System.out.println("Animal " +animal + " est ajout�");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Zoo aZoo = new Zoo(); 
		aZoo.addAnimal(new Elephant(1500)); 
		aZoo.addAnimal(new Anaconda());
		
		//Zoo ref = new Elephant(1000);
	
	
	}

}
