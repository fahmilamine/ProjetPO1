package interfaceExo2;

public interface Animal {
	
	
	public int getNbLegs();
	
	public boolean isCarvnivorous();
	

}
