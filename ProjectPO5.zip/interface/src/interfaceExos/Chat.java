package interfaceExos;

public class Chat implements criAnimaux {
	
	public void crier() {
		
		System.out.println("MIAOUH..!!!!");
	}
	

}
