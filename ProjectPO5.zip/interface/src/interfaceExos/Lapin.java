package interfaceExos;

public class Lapin implements criAnimaux{
	
	
public void crier() {}

}
