package interfaceExos;

public class Test {

	public static void main(String[] args) {
		
		criAnimaux tab[] = new criAnimaux[4];
		
		Chat c1 = new Chat();
		Chat c2 = new Chat();
		Chien ch1 = new Chien();
		Chien ch2 = new Chien();
		
		tab[0] = c1;

		tab[1] = c2;

		tab[2] = ch1;

		tab[3] = ch2;
		
		
		for(int i=0; i<tab.length; i++)
			tab[i].crier();

	}

}
