package interfaceExos;

public class Chien implements criAnimaux {

	@Override
	public void crier() {
		System.out.println("WAA...WAAF.!!!!");
		
	}

}
