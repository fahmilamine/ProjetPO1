package interfaceExos;

public interface criAnimaux {
	
	void crier();

}
