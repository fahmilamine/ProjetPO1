package interface1;

public class Tri implements Comparable {
	
public static void trier(Comparable[] tableau, int nbElem) {
	 Comparable tempo;
	 for(int i = 0 ; i < nbElem-1; i++) {
	 int indMin = i;
	 for(int j = i+1 ; j < nbElem; j++)
	 if (tableau[j].plusPetit(tableau[indMin]))
	 indMin = j;
	 if (indMin != i) {
	 tempo = tableau[i];
	 tableau[i]=tableau[indMin];
	 tableau[indMin]=tempo;
	 }
	 }
	 }

@Override
public boolean plusPetit(Object obj) {
	// TODO Auto-generated method stub
	return false;
}





}



