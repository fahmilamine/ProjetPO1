package interface1;

public class Test {

	// afficher le tableau d'objets (personnes, rectangles, ...)
		static void afficher(Object [] obj, String message) {
		System.out.println(message);
		for(int i = 0 ; i < obj.length ; i++)
		 System.out.println(obj[i]);
		System.out.println();
		}
	public static void main (String[] args)
	{
	 Personne2 pers[] = { new Personne2(1.75, 65.3, 'M'),
	 new Personne2(1.62, 69.1, 'F'),
	 new Personne2(1.89, 76.5, 'F'),
	 new Personne2(1.45, 50.3, 'M'),
	 new Personne2(1.77, 90.1, 'M')
	 };
	afficher(pers, "Lite des personnes avant le tri");
	Tri.trier(pers, pers.length);
	afficher(pers, "Lite des personnes apres le tri");
	Rectangle3 rect[] = { new Rectangle3(12, 5),
	 new Rectangle3(9, 6),
	 new Rectangle3(60, 12),
	 new Rectangle3(5, 12)};
	 afficher(rect, "Lite des rectangles avant le tri" +
	 " selon la surface : ");
	 Tri.trier(rect, rect.length);
	 afficher(rect, "Lite des rectangles apres le tri selon" +
	 " la surface : ");

}
	
}
