package interface1;

public interface uneinterface {
	
	public int test1();
	public int test2();
	public int test3();
	public int test4();
	public int test5();
	

}
