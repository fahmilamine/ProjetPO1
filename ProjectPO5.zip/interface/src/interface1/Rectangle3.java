package interface1;

public class Rectangle3 implements Comparable
{ // attributs (champs de donn�es, membres de donn�es)
private int longueur, largeur;
public Rectangle3() { }
public Rectangle3(int lo, int largeur) {
longueur = lo;
this.largeur = largeur;
}
public Rectangle3(int c) {
this(c, c);
}
// m�thode pour calculer et retourner le p�rim�tre
public int perimetre(){
return 2 * (longueur + largeur);
}
// m�thode pour calculer et retourner la surface
public int surface() {
return longueur * largeur ;
}
public int getLongueur() { return longueur ; }
public int getLargeur() { return largeur ; }

// On s'engage � IMPL�MENTER la m�thode "plusPetit" public
 public boolean plusPetit(Object r) {
return this.surface() < ( (Rectangle3) r).surface();
}
public String toString() {
return "<longueur : " + longueur + ", " + largeur + ", surface : " + surface() + ">";
}

}
