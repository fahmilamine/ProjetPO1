package interface2;

public interface CalculGeometrique {
	
	public double surface();
	public double perimetre();

}
