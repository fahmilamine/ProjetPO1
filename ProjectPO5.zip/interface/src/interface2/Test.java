package interface2;

public class Test {

	public static void main(String[] args) {
		
		
		Cercle c1 = new Cercle(12);
		
		
		Rectangle r1 = new Rectangle(25,20);
		
		
		System.out.println("Surface cercle : " + c1.surface());
		System.out.println("Perimetre cercle : " + c1.perimetre()+"\n\n");
		
		System.out.println("Surface rectangle : " + r1.surface());
		System.out.println("premietre rectangle : " + r1.perimetre());

	}

}
